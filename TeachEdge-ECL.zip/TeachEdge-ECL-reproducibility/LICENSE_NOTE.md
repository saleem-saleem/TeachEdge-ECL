# License note

No software license has been selected automatically. Before publishing this repository, the authors should choose a license consistent with their institution, journal, third-party dependencies, and intended reuse (for example MIT, BSD-3-Clause, Apache-2.0, or another approved license).
