# Data and artifact policy

The public Kaggle dataset is not redistributed in this repository. The download helper retrieves it into `data/raw/`, which is ignored by Git by default.

Generated model artifacts are also ignored by default because they can be large and because journal repositories often have separate artifact hosting rules. If the journal requires trained weights to be public, upload the final `model.keras`, `model.tflite`, `preprocessor.joblib`, `quartiles.json`, and `feature_importance.csv` to the approved release/archive and record checksums.

Never commit `kaggle.json`, API keys, passwords, local absolute paths, or private institutional data.
