# TeachEdge-ECL model card

## Intended task
Three-class prediction of teaching effectiveness (Low, Medium, High) from the Teacher–Student Teaching Effectiveness dataset, followed by transparent indicator flags for teacher review.

## Intended use
Research reproduction and educational decision-support experiments. The system is not a causal intervention engine and does not prescribe teaching strategies.

## Data
2,040 usable cross-sectional records in the manuscript. Classes are imbalanced. The dataset has no timestamps, so the LSTM sequence is a modelling arrangement over PCA components, not a claim of temporal dynamics.

## Model
Hybrid 1D convolutional feature extractor plus two LSTM layers and a softmax classifier. ESO tunes learning rate, filter multiplier, LSTM units, dropout and batch size.

## Decision support
Permutation importance is calculated on original attributes. A classroom indicator is flagged when its model importance is positive and its normalized value is below the training-set first quartile. The teacher decides what action, if any, to take.

## Evaluation
Held-out 20% test set; repeated stratified 5-fold CV on the 80% development set with three seeds; macro-averaged metrics; corrected resampled t-tests with Holm adjustment; ablation and optimizer benchmarks.

## Edge deployment
Float32 TensorFlow Lite model on Raspberry Pi 5. The benchmark includes preprocessing and decision-support logic in end-to-end latency.

## Limitations
One public dataset, cross-sectional records, no prospective classroom intervention, and hardware-dependent timing. SG smoothing on non-temporal ordered records is specifically tested by ablation and should be interpreted cautiously.
