# ESO implementation notes

The repository implements the five-dimensional candidate vector

`[learning_rate, filter_multiplier, LSTM_units, dropout, batch_index]`

within the bounds declared in `configs/paper.yaml`. Batch index 0/1/2 maps to 16/32/64.

The fitness is

`F(x) = 1 - macro_F1_validation(x)`.

With 10 squads and 20 iterations, the implementation evaluates the initial 10 squad positions and three proposed positions for each squad during every iteration:

`10 + 3 * 10 * 20 = 610` fitness evaluations.

For each squad, the code implements:

1. a linear local observation model and pseudo-gradient direction;
2. correction directions based on the squad/personal best and global best;
3. adaptive moment tracking using beta1=0.90 and beta2=0.999;
4. Egret A's decaying sit-and-wait move;
5. Egret B's tangent random walk;
6. Egret C's encircling move;
7. best-of-three candidate selection;
8. acceptance of a worse selected candidate with probability 0.30;
9. clipping to search bounds.

Tiny epsilons are added only where required to prevent division by zero. Every candidate and the running best are written to the evaluation log. This allows the convergence figure to be regenerated from actual optimizer calls instead of hand-entered values.
