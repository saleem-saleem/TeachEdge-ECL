# Semantic data codebook

The loader maps source-column spellings to the following canonical variables. The actual source spelling is printed by `scripts/01_validate_dataset.py` and saved in `outputs/dataset_manifest.json`.

| Canonical field | Role | Treatment |
|---|---|---|
| `student_id` | identifier | removed |
| `teacher_id` | identifier | removed |
| `age` | teacher attribute | numeric, min–max scaled |
| `gender` | teacher attribute | one-hot encoded |
| `experience` | years of teaching experience | numeric, min–max scaled |
| `subject_stream` | teacher/subject attribute | one-hot encoded |
| `attention` | classroom indicator | scaled, SG-smoothed, flaggable |
| `engagement` | classroom indicator | scaled, SG-smoothed, flaggable |
| `interaction` | classroom indicator | scaled, SG-smoothed, flaggable |
| `learning_gain` | classroom indicator | scaled, SG-smoothed, flaggable |
| `target` | Teaching Effectiveness | Low=0, Medium=1, High=2 |

## Preprocessing order

1. Remove identifiers.
2. Drop incomplete and duplicate usable records.
3. Stratified split.
4. Fit numeric min–max limits on training rows only.
5. Fit categorical one-hot encoder on training rows only.
6. Apply SG filter separately within each subset to scaled classroom indicators.
7. Concatenate scaled numeric and one-hot categorical features.
8. Fit PCA on training rows only to retain at least 95% explained variance.
9. Arrange each PCA vector as `(components, 1)` for the 1D Conv-LSTM.
