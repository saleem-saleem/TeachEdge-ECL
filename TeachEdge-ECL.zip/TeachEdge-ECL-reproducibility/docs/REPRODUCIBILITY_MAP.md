# Manuscript-to-code reproducibility map

| Manuscript element | Repository implementation | Primary output |
|---|---|---|
| Section 3.1 dataset | `data.py`, `01_validate_dataset.py` | `outputs/dataset_manifest.json` |
| Section 3.2 split/cleaning/scaling/SG | `data.py`, `preprocessing.py` | fitted `artifacts/preprocessor.joblib` |
| Section 3.3 PCA | `preprocessing.py` | PCA object inside preprocessor + manifest |
| Section 3.4 Conv-LSTM | `models.py` | `artifacts/model.keras` |
| Section 3.5 ESO | `optimizers/eso.py` | `outputs/search/eso_evaluations.csv`, `eso_best.json` |
| Table 3 fixed/search settings | `configs/paper.yaml` | configuration source of truth |
| Section 3.7 decision support | `decision_support.py`, scripts 09-10 | importance and flags CSVs |
| Section 3.8 edge deployment | scripts 11-12 | `.tflite`, edge benchmark JSON/CSV |
| Section 3.9 metrics | `metrics.py` | hold-out/classwise/additional metrics |
| Section 3.9.2 repeated CV | `evaluation.py`, script 05 | 15 CV rows |
| Section 3.9.3 ablation | script 06 | ablation table + paired CV files |
| Optimizer benchmark | script 07 | 4 search logs + benchmark table |
| Six baseline methods | `baselines.py`, script 08 | baseline summary + CV logs |
| Corrected t-test + Holm | `stats.py` | p-values and confidence intervals |
| Section 3.10 reproducibility | README, environment files | exact software/hardware instructions |
| Figure 7 learning curves | script 03 + script 13 | training history and 300-dpi figures |
| Figure 8 confusion matrix | script 04 + script 13 | `confusion_matrix.csv` + figure |
| Figure 9 optimizer convergence | script 07 + script 13 | checkpoint CSV + figure |
| Figure 10 permutation importance | script 09 + script 13 | importance CSV + figure |
| Appendix A Table A1 | script 05 | 15-run CSV |
| Appendix B additional metrics | `metrics.py`, script 04 | additional metrics CSV/JSON |

## Leakage control

The repository deliberately keeps the following operations inside the training boundary:

1. The held-out test set is separated before model fitting.
2. Min–max limits and one-hot categories are fitted on training rows only.
3. The SG filter is applied separately inside each subset after scaling.
4. PCA is fitted on training rows only.
5. ESO receives validation macro-F1 only; it never receives test scores.
6. In repeated CV, preprocessing and PCA are refitted in each training fold.
7. CV fold test data are not used for early stopping. The main-run restored epoch is fixed for all fold training.

## Exact and implementation-defined details

The manuscript fully specifies the split, SG parameters, PCA threshold, Conv-LSTM macro-architecture, hyperparameter ranges, ESO budget and main optimizer constants. Some software-level choices are necessarily explicit in code even when not separately stated in prose:

- pooling uses `padding='same'` so short PCA sequences remain valid through three blocks;
- dense-unit channel growth is compressed back to the block filter count with a 1x1 transition convolution;
- divisions/norms in ESO use a small epsilon for numerical stability;
- the GA benchmark uses steady-state replacement so exactly 610 objective evaluations are possible with a population of 30;
- baseline hyperparameter grids are listed directly in `baselines.py` so they can be audited.

If the authors used different low-level choices in the original experiment, edit these before public release and record the change in the README.
