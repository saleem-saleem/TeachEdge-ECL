#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import time
import numpy as np
import pandas as pd
from _bootstrap import setup_path
ROOT = setup_path()

from teachedge_ecl.config import load_config
from teachedge_ecl.experiment import prepare_main_split, make_search_objective
from teachedge_ecl.optimizers import EgretSwarmOptimizer, ParticleSwarmOptimizer, GeneticAlgorithmOptimizer, RandomSearchOptimizer
from teachedge_ecl.training import train_model, cleanup_model
from teachedge_ecl.evaluation import evaluate_keras_model, repeated_cv
from teachedge_ecl.stats import corrected_resampled_ttest, holm_adjust
from teachedge_ecl.io_utils import ensure_dir, save_json, load_json


def run_search(name, cfg, prepared, rerun=False):
    out = ensure_dir(ROOT / "outputs" / "search")
    best_file = out / f"{name}_best.json"
    log_file = out / f"{name}_evaluations.csv"
    if not rerun and best_file.exists() and log_file.exists():
        payload = load_json(best_file)
        return payload, pd.read_csv(log_file)
    objective = make_search_objective(prepared, cfg)
    budget = int(cfg["eso"]["squads"] + 3 * cfg["eso"]["squads"] * cfg["eso"]["iterations"])
    seed = int(cfg["project"]["seed"])
    cls = {"eso": EgretSwarmOptimizer, "pso": ParticleSwarmOptimizer,
           "ga": GeneticAlgorithmOptimizer, "random": RandomSearchOptimizer}[name]
    opt = cls(cfg, seed=seed) if name == "eso" else cls(cfg, seed=seed, budget=budget)
    t0 = time.perf_counter()
    result = opt.run(objective)
    elapsed_h = (time.perf_counter() - t0) / 3600
    result.log.to_csv(log_file, index=False)
    payload = {"optimizer": name, "best_fitness": result.best_fitness,
               "best_validation_macro_f1": 1-result.best_fitness, "best_params": result.best_params,
               "evaluations": result.evaluations, "elapsed_hours": elapsed_h}
    save_json(payload, best_file)
    return payload, result.log


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/paper.yaml")
    ap.add_argument("--rerun-search", action="store_true")
    args = ap.parse_args()
    cfg = load_config(ROOT / args.config)
    prepared = prepare_main_split(cfg)
    out = ensure_dir(ROOT / "outputs" / "search")
    rows, cv_map = [], {}
    for name in ["random", "ga", "pso", "eso"]:
        payload, log = run_search(name, cfg, prepared, rerun=args.rerun_search)
        hp = payload["best_params"]
        result = train_model(prepared.X_train, prepared.y_train, prepared.X_validation, prepared.y_validation,
                             cfg, hp, variant="full", seed=cfg["project"]["seed"])
        test_summary, _, _ = evaluate_keras_model(result.model, prepared.X_test, prepared.y_test,
                                                  cfg["dataset"]["class_order"])
        cleanup_model(result.model)
        cv = repeated_cv(prepared.bundle.development, cfg, hp, fixed_epochs=cfg["validation"]["fixed_epochs"])
        cv.to_csv(out / f"{name}_cv_runs.csv", index=False)
        scores = cv["Macro-F1 (%)"].to_numpy() / 100
        cv_map[name] = scores
        rows.append({"Optimizer": name, "Fitness evaluations": payload["evaluations"],
                     "Best validation fitness": payload["best_fitness"],
                     "Test macro-F1 (%)": 100*test_summary["macro_f1"],
                     "CV macro-F1 mean (%)": 100*scores.mean(), "CV macro-F1 SD (%)": 100*scores.std(ddof=1),
                     "Search time (h)": payload["elapsed_hours"]})
    raw_ps, stats_rows = [], []
    for name in ["random", "ga", "pso"]:
        st = corrected_resampled_ttest(cv_map["eso"], cv_map[name], train_size=4, test_size=1)
        raw_ps.append(st["p_raw"]); stats_rows.append(st)
    adj = holm_adjust(raw_ps)
    for row in rows:
        if row["Optimizer"] == "eso":
            row["p Holm"] = np.nan
        else:
            j = ["random", "ga", "pso"].index(row["Optimizer"])
            row["p Holm"] = adj[j]
            row["t"] = stats_rows[j]["t"]
    table = pd.DataFrame(rows)
    table.to_csv(out / "optimizer_benchmark_summary.csv", index=False)

    # Common convergence checkpoints used by the paper figure: 10, then every 30, ending at 610.
    checkpoints = [10] + list(range(40, 611, 30))
    conv = pd.DataFrame({"evaluations": checkpoints})
    for name in ["eso", "pso", "ga", "random"]:
        log = pd.read_csv(out / f"{name}_evaluations.csv")
        vals = []
        for cp in checkpoints:
            eligible = log[log["evaluation"] <= cp]
            vals.append(float(eligible["best_fitness"].iloc[-1]))
        conv[name.upper() if name != "random" else "Random search"] = vals
    conv.to_csv(out / "optimizer_convergence_checkpoints.csv", index=False)
    print(table.to_string(index=False))


if __name__ == "__main__":
    main()
