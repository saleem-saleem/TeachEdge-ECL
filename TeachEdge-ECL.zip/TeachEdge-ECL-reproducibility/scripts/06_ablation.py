#!/usr/bin/env python
from __future__ import annotations

import argparse
import numpy as np
import pandas as pd
from _bootstrap import setup_path
ROOT = setup_path()

from teachedge_ecl.config import load_config
from teachedge_ecl.data import load_canonical_dataset, split_dataset, encode_labels
from teachedge_ecl.preprocessing import TeachEdgePreprocessor
from teachedge_ecl.training import train_model, cleanup_model
from teachedge_ecl.evaluation import evaluate_keras_model, repeated_cv
from teachedge_ecl.stats import corrected_resampled_ttest, holm_adjust
from teachedge_ecl.io_utils import ensure_dir, load_json


VARIANTS = [
    ("MLP on PCA input", "mlp", True, True, "selected"),
    ("CNN only (no LSTM)", "cnn_only", True, True, "selected"),
    ("LSTM only (no convolution)", "lstm_only", True, True, "selected"),
    ("Conv-LSTM no ESO (default values)", "full", True, True, "default"),
    ("Without SG smoothing", "full", False, True, "selected"),
    ("Without PCA", "full", True, False, "selected"),
    ("Full TeachEdge-ECL", "full", True, True, "selected"),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/paper.yaml")
    args = ap.parse_args()
    cfg = load_config(ROOT / args.config)
    selected = load_json(ROOT / "artifacts" / "selected_hyperparameters.json") if (ROOT / "artifacts" / "selected_hyperparameters.json").exists() else cfg["paper_selected_hyperparameters"]
    df, _, _ = load_canonical_dataset(cfg)
    bundle = split_dataset(df, cfg)
    out = ensure_dir(ROOT / "outputs" / "ablation")
    rows = []
    cv_scores = {}
    for label, model_variant, use_sg, use_pca, hp_kind in VARIANTS:
        hyper = cfg["default_hyperparameters"] if hp_kind == "default" else selected
        prep = TeachEdgePreprocessor(cfg, use_sg=use_sg, use_pca=use_pca).fit(bundle.train)
        Xtr, Xv, Xte = prep.transform(bundle.train), prep.transform(bundle.validation), prep.transform(bundle.test)
        ytr = encode_labels(bundle.train["target"], cfg)
        yv = encode_labels(bundle.validation["target"], cfg)
        yte = encode_labels(bundle.test["target"], cfg)
        result = train_model(Xtr, ytr, Xv, yv, cfg, hyper, variant=model_variant, seed=cfg["project"]["seed"])
        summary, _, _ = evaluate_keras_model(result.model, Xte, yte, cfg["dataset"]["class_order"])
        cleanup_model(result.model)
        cv = repeated_cv(bundle.development, cfg, hyper, variant=model_variant, use_sg=use_sg, use_pca=use_pca,
                         fixed_epochs=cfg["validation"]["fixed_epochs"])
        cv.to_csv(out / (label.lower().replace(" ", "_").replace("/", "_").replace("(", "").replace(")", "") + "_cv.csv"), index=False)
        scores = cv["Macro-F1 (%)"].to_numpy() / 100.0
        cv_scores[label] = scores
        rows.append({
            "Variant": label,
            "Accuracy (%)": 100 * summary["accuracy"],
            "Macro-P (%)": 100 * summary["macro_precision"],
            "Macro-R (%)": 100 * summary["macro_recall"],
            "Macro-F1 (%)": 100 * summary["macro_f1"],
            "CV macro-F1 mean (%)": 100 * scores.mean(),
            "CV macro-F1 SD (%)": 100 * scores.std(ddof=1),
        })
    full = cv_scores["Full TeachEdge-ECL"]
    p_raw = []
    test_rows = []
    for row in rows[:-1]:
        comp = cv_scores[row["Variant"]]
        stat = corrected_resampled_ttest(full, comp, train_size=4, test_size=1)
        p_raw.append(stat["p_raw"])
        test_rows.append(stat)
    p_holm = holm_adjust(p_raw)
    full_mean = rows[-1]["CV macro-F1 mean (%)"]
    for i, row in enumerate(rows):
        if i < len(rows) - 1:
            row["Delta CV macro-F1 vs full"] = row["CV macro-F1 mean (%)"] - full_mean
            row["t"] = test_rows[i]["t"]
            row["p raw"] = test_rows[i]["p_raw"]
            row["p Holm"] = p_holm[i]
            row["CI95 low (pp)"] = 100 * test_rows[i]["ci95_low"]
            row["CI95 high (pp)"] = 100 * test_rows[i]["ci95_high"]
        else:
            row.update({"Delta CV macro-F1 vs full": np.nan, "t": np.nan, "p raw": np.nan, "p Holm": np.nan,
                        "CI95 low (pp)": np.nan, "CI95 high (pp)": np.nan})
    table = pd.DataFrame(rows)
    table.to_csv(out / "ablation_summary.csv", index=False)
    print(table.to_string(index=False))


if __name__ == "__main__":
    main()
