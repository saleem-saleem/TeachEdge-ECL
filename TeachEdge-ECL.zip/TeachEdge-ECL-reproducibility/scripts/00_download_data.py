#!/usr/bin/env python
from __future__ import annotations

import argparse
import shutil
import subprocess
from pathlib import Path
from _bootstrap import setup_path
ROOT = setup_path()

from teachedge_ecl.config import load_config


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/paper.yaml")
    args = ap.parse_args()
    cfg = load_config(ROOT / args.config)
    slug = cfg["dataset"]["kaggle_slug"]
    dest = ROOT / "data" / "raw"
    dest.mkdir(parents=True, exist_ok=True)
    if shutil.which("kaggle") is None:
        raise SystemExit(
            "The Kaggle CLI is not available. Install requirements.txt, configure Kaggle credentials, "
            "or download the dataset manually into data/raw/."
        )
    cmd = ["kaggle", "datasets", "download", "-d", slug, "-p", str(dest), "--unzip"]
    print("Running:", " ".join(cmd))
    subprocess.run(cmd, check=True)
    csvs = sorted(dest.glob("**/*.csv"))
    print(f"Downloaded {len(csvs)} CSV file(s):")
    for p in csvs:
        print(" -", p.relative_to(ROOT))


if __name__ == "__main__":
    main()
