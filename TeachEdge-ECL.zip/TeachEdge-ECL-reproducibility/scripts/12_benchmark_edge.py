#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import platform
import time
import numpy as np
import pandas as pd
import joblib
import psutil
from _bootstrap import setup_path
ROOT=setup_path()

from teachedge_ecl.config import load_config
from teachedge_ecl.data import load_canonical_dataset, split_dataset, CLASSROOM_INDICATORS
from teachedge_ecl.models import as_sequence
from teachedge_ecl.edge import load_tflite_interpreter
from teachedge_ecl.io_utils import ensure_dir, save_json


def make_tflite_batch_predict(interpreter):
    def predict(Xseq):
        Xseq=np.asarray(Xseq,dtype=np.float32)
        inp=interpreter.get_input_details()[0]
        out=interpreter.get_output_details()[0]
        if tuple(inp["shape"]) != tuple(Xseq.shape):
            interpreter.resize_tensor_input(inp["index"],Xseq.shape,strict=False); interpreter.allocate_tensors()
            inp=interpreter.get_input_details()[0]; out=interpreter.get_output_details()[0]
        interpreter.set_tensor(inp["index"],Xseq.astype(inp["dtype"])); interpreter.invoke()
        return interpreter.get_tensor(out["index"])
    return predict


def main():
    import tensorflow as tf
    ap=argparse.ArgumentParser()
    ap.add_argument("--config",default="configs/paper.yaml")
    ap.add_argument("--model-format",choices=["keras","tflite"],default="tflite")
    ap.add_argument("--backend",choices=["auto","tensorflow","tflite_runtime"],default="auto")
    args=ap.parse_args(); cfg=load_config(ROOT/args.config)
    prep=joblib.load(ROOT/"artifacts"/"preprocessor.joblib")
    df,_,_=load_canonical_dataset(cfg); bundle=split_dataset(df,cfg); test=bundle.test.reset_index(drop=True)
    X_batch=prep.transform(test); Xseq=as_sequence(X_batch)
    if args.model_format=="keras":
        model=tf.keras.models.load_model(ROOT/"artifacts"/"model.keras")
        backend="tensorflow.keras"
        predict_batch=lambda X: model.predict(X,batch_size=len(X),verbose=0)
    else:
        interpreter,backend=load_tflite_interpreter(ROOT/"artifacts"/"model.tflite",args.backend)
        predict_batch=make_tflite_batch_predict(interpreter)

    importance_path=ROOT/"artifacts"/"feature_importance.csv"
    importance=pd.read_csv(importance_path) if importance_path.exists() else pd.DataFrame({"attribute":CLASSROOM_INDICATORS,"mean_drop_macro_f1":[1,1,1,1]})
    imp=dict(zip(importance.attribute,importance.mean_drop_macro_f1))
    history={x:[] for x in CLASSROOM_INDICATORS}; counter={"i":0}
    process=psutil.Process(); peak=process.memory_info().rss

    def one_record():
        i=counter["i"]%len(test); counter["i"]+=1
        record=test.iloc[[i]]
        X, new_hist=prep.transform_single_with_history(record,history)
        history.update(new_hist)
        probs=predict_batch(as_sequence(X))[0]
        # Decision support is intentionally executed inside the timed path.
        scaled=prep.scaled_indicator_values(record).iloc[0]
        flags=[name for name in CLASSROOM_INDICATORS if imp.get(name,0)>0 and float(scaled[name])<float(prep.quartiles_scaled[name])]
        return int(np.argmax(probs)), float(np.max(probs)), flags

    warm=int(cfg["edge"]["warmup_runs"]); timed=int(cfg["edge"]["timed_single_record_runs"])
    for _ in range(warm): one_record()
    lat=[]
    for _ in range(timed):
        t0=time.perf_counter_ns(); one_record(); t1=time.perf_counter_ns(); lat.append((t1-t0)/1e6)
        peak=max(peak,process.memory_info().rss)
    lat=np.asarray(lat)
    bs=int(cfg["edge"]["throughput_batch_size"]); batches=int(cfg["edge"]["throughput_batches"])
    sample=np.resize(Xseq,(bs,Xseq.shape[1],Xseq.shape[2])).astype(np.float32)
    t0=time.perf_counter();
    for _ in range(batches): predict_batch(sample)
    elapsed=time.perf_counter()-t0; throughput=bs*batches/elapsed

    model_path=ROOT/"artifacts"/("model.keras" if args.model_format=="keras" else "model.tflite")
    bundle_files=[model_path,ROOT/"artifacts"/"preprocessor.joblib",ROOT/"artifacts"/"quartiles.json",ROOT/"artifacts"/"feature_importance.csv"]
    bundle_mb=sum(p.stat().st_size for p in bundle_files if p.exists())/(1024**2)
    metrics={
        "model_format":args.model_format,"backend":backend,"platform":platform.platform(),"python":platform.python_version(),
        "model_and_preprocessing_size_mb":bundle_mb,"peak_memory_mb":peak/(1024**2),
        "latency_mean_ms":float(lat.mean()),"latency_sd_ms":float(lat.std(ddof=1)),"latency_p95_ms":float(np.percentile(lat,95)),
        "throughput_records_per_s":float(throughput),"warmup_runs":warm,"timed_runs":timed,
    }
    out=ensure_dir(ROOT/"outputs"/"edge"); save_json(metrics,out/f"benchmark_{args.model_format}_{platform.machine()}.json")
    pd.DataFrame({"latency_ms":lat}).to_csv(out/f"latencies_{args.model_format}_{platform.machine()}.csv",index=False)
    print(json.dumps(metrics,indent=2))


if __name__=="__main__": main()
