#!/usr/bin/env python
from __future__ import annotations

import argparse
import copy
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import f1_score
from _bootstrap import setup_path
ROOT = setup_path()

from teachedge_ecl.config import load_config
from teachedge_ecl.data import load_canonical_dataset, split_dataset, encode_labels
from teachedge_ecl.preprocessing import TeachEdgePreprocessor
from teachedge_ecl.baselines import tune_sklearn_baseline
from teachedge_ecl.metrics import classification_summary
from teachedge_ecl.training import train_model, predict_probabilities, cleanup_model
from teachedge_ecl.stats import corrected_resampled_ttest, holm_adjust
from teachedge_ecl.io_utils import ensure_dir, load_json, save_json


def sklearn_cv(model, development, cfg):
    y_all = encode_labels(development["target"], cfg)
    rows=[]
    for seed in cfg["validation"]["repeat_seeds"]:
        skf=StratifiedKFold(n_splits=cfg["validation"]["folds"],shuffle=True,random_state=seed)
        for fold,(tr_idx,te_idx) in enumerate(skf.split(development,y_all),1):
            tr=development.iloc[tr_idx].sort_values("_row_order").reset_index(drop=True)
            te=development.iloc[te_idx].sort_values("_row_order").reset_index(drop=True)
            prep=TeachEdgePreprocessor(cfg).fit(tr)
            Xtr,Xte=prep.transform(tr),prep.transform(te)
            ytr,yte=encode_labels(tr["target"],cfg),encode_labels(te["target"],cfg)
            m=clone(model); m.fit(Xtr,ytr); pred=m.predict(Xte)
            s=classification_summary(yte,pred,cfg["dataset"]["class_order"])
            rows.append({"Seed":seed,"Fold":fold,"Macro-F1 (%)":100*s["macro_f1"]})
    return pd.DataFrame(rows)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--config",default="configs/paper.yaml"); args=ap.parse_args()
    cfg=load_config(ROOT/args.config)
    selected=load_json(ROOT/"artifacts"/"selected_hyperparameters.json") if (ROOT/"artifacts"/"selected_hyperparameters.json").exists() else cfg["paper_selected_hyperparameters"]
    df,_,_=load_canonical_dataset(cfg); bundle=split_dataset(df,cfg)
    prep=TeachEdgePreprocessor(cfg).fit(bundle.train)
    Xtr,Xv,Xte=prep.transform(bundle.train),prep.transform(bundle.validation),prep.transform(bundle.test)
    ytr,yv,yte=encode_labels(bundle.train["target"],cfg),encode_labels(bundle.validation["target"],cfg),encode_labels(bundle.test["target"],cfg)
    out=ensure_dir(ROOT/"outputs"/"baselines")
    rows=[]; cv_map={}
    for name in ["Decision tree","Random forest","XGBoost","SVM","ANN"]:
        model,best_val,tuning=tune_sklearn_baseline(name,Xtr,ytr,Xv,yv,seed=cfg["project"]["seed"])
        pd.DataFrame(tuning).to_csv(out/(name.lower().replace(" ","_")+"_tuning.csv"),index=False)
        pred=model.predict(Xte); s=classification_summary(yte,pred,cfg["dataset"]["class_order"])
        cv=sklearn_cv(model,bundle.development,cfg); cv.to_csv(out/(name.lower().replace(" ","_")+"_cv.csv"),index=False)
        scores=cv["Macro-F1 (%)"].to_numpy()/100; cv_map[name]=scores
        rows.append({"Model":name,"Accuracy (%)":100*s["accuracy"],"Macro-P (%)":100*s["macro_precision"],
                     "Macro-R (%)":100*s["macro_recall"],"Macro-F1 (%)":100*s["macro_f1"],
                     "CV macro-F1 mean (%)":100*scores.mean(),"CV macro-F1 SD (%)":100*scores.std(ddof=1)})

    # CNN baseline: grid-search a compact 1D CNN on the same PCA input.
    cnn_candidates=[]
    for lr in [0.001,0.0005]:
        for mult in [0.5,1.0]:
            for drop in [0.25,0.30]:
                hp=dict(selected); hp.update({"learning_rate":lr,"filter_multiplier":mult,"dropout":drop,"lstm_units":128,"batch_size":32})
                r=train_model(Xtr,ytr,Xv,yv,cfg,hp,variant="cnn_only",seed=cfg["project"]["seed"])
                p=predict_probabilities(r.model,Xv).argmax(1); score=f1_score(yv,p,average="macro")
                cnn_candidates.append((score,hp)); cleanup_model(r.model)
    cnn_candidates.sort(key=lambda z:z[0],reverse=True); cnn_hp=cnn_candidates[0][1]
    r=train_model(Xtr,ytr,Xv,yv,cfg,cnn_hp,variant="cnn_only",seed=cfg["project"]["seed"])
    p=predict_probabilities(r.model,Xte).argmax(1); s=classification_summary(yte,p,cfg["dataset"]["class_order"]); cleanup_model(r.model)
    # CNN repeated CV via common neural CV helper.
    from teachedge_ecl.evaluation import repeated_cv
    cv=repeated_cv(bundle.development,cfg,cnn_hp,variant="cnn_only",fixed_epochs=cfg["validation"]["fixed_epochs"])
    cv.to_csv(out/"cnn_cv.csv",index=False); scores=cv["Macro-F1 (%)"].to_numpy()/100; cv_map["CNN"]=scores
    save_json(cnn_hp,out/"cnn_selected_hyperparameters.json")
    rows.append({"Model":"CNN","Accuracy (%)":100*s["accuracy"],"Macro-P (%)":100*s["macro_precision"],
                 "Macro-R (%)":100*s["macro_recall"],"Macro-F1 (%)":100*s["macro_f1"],
                 "CV macro-F1 mean (%)":100*scores.mean(),"CV macro-F1 SD (%)":100*scores.std(ddof=1)})

    # Full model CV reference.
    full_cv_path=ROOT/"outputs"/"cv"/"teachedge_cv_runs.csv"
    if full_cv_path.exists():
        full_cv=pd.read_csv(full_cv_path)
    else:
        from teachedge_ecl.evaluation import repeated_cv
        full_cv=repeated_cv(bundle.development,cfg,selected,fixed_epochs=cfg["validation"]["fixed_epochs"])
    full_scores=full_cv["Macro-F1 (%)"].to_numpy()/100
    # Full test summary (train once if needed).
    rr=train_model(Xtr,ytr,Xv,yv,cfg,selected,variant="full",seed=cfg["project"]["seed"])
    pp=predict_probabilities(rr.model,Xte).argmax(1); ss=classification_summary(yte,pp,cfg["dataset"]["class_order"]); cleanup_model(rr.model)
    rows.append({"Model":"TeachEdge-ECL","Accuracy (%)":100*ss["accuracy"],"Macro-P (%)":100*ss["macro_precision"],
                 "Macro-R (%)":100*ss["macro_recall"],"Macro-F1 (%)":100*ss["macro_f1"],
                 "CV macro-F1 mean (%)":100*full_scores.mean(),"CV macro-F1 SD (%)":100*full_scores.std(ddof=1)})

    raw=[]; stats=[]
    for name in ["Decision tree","Random forest","XGBoost","SVM","ANN","CNN"]:
        st=corrected_resampled_ttest(full_scores,cv_map[name],train_size=4,test_size=1); raw.append(st["p_raw"]); stats.append(st)
    adj=holm_adjust(raw)
    for row in rows:
        if row["Model"]=="TeachEdge-ECL": row["t"]=np.nan; row["p Holm"]=np.nan
        else:
            j=["Decision tree","Random forest","XGBoost","SVM","ANN","CNN"].index(row["Model"])
            row["t"]=stats[j]["t"]; row["p Holm"]=adj[j]
    table=pd.DataFrame(rows); table.to_csv(out/"baseline_summary.csv",index=False); print(table.to_string(index=False))


if __name__=="__main__": main()
