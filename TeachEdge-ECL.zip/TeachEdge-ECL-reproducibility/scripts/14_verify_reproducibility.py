#!/usr/bin/env python
from __future__ import annotations

import argparse
import math
import numpy as np
import pandas as pd
from _bootstrap import setup_path
ROOT=setup_path()

from teachedge_ecl.config import load_config
from teachedge_ecl.metrics import classification_summary, additional_confusion_metrics


def close(a,b,tol=0.015):
    return abs(float(a)-float(b))<=tol


def check(condition,msg,failures):
    print(("PASS" if condition else "FAIL"),"-",msg)
    if not condition: failures.append(msg)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--config",default="configs/paper.yaml"); args=ap.parse_args(); cfg=load_config(ROOT/args.config)
    failures=[]
    P=cfg["eso"]["squads"]; t=cfg["eso"]["iterations"]
    check(P+3*P*t==610,"ESO budget P + 3Pt_max = 610",failures)
    mult=cfg["paper_selected_hyperparameters"]["filter_multiplier"]
    filters=[round(x*mult) for x in cfg["model"]["base_filters"]]
    check(filters==[80,160,320],"1.25 multiplier gives 80/160/320 filters",failures)
    fit=cfg["reference"]["best_validation_fitness"]
    check(close((1-fit)*100,94.76,1e-9),"0.0524 fitness equals 94.76% validation macro-F1",failures)

    cm=pd.read_csv(ROOT/"reference"/"confusion_matrix.csv",index_col=0).to_numpy(dtype=int)
    y_true=[]; y_pred=[]
    for i in range(3):
        for j in range(3):
            y_true.extend([i]*cm[i,j]); y_pred.extend([j]*cm[i,j])
    s=classification_summary(y_true,y_pred)
    check(cm.sum()==408,"reference confusion matrix contains 408 test records",failures)
    check(np.trace(cm)==389,"reference confusion matrix has 389 correct predictions",failures)
    check(close(100*s["accuracy"],95.34),"confusion matrix -> 95.34% accuracy",failures)
    check(close(100*s["macro_precision"],94.49),"confusion matrix -> 94.49% macro-precision",failures)
    check(close(100*s["macro_recall"],94.73),"confusion matrix -> 94.73% macro-recall",failures)
    check(close(100*s["macro_f1"],94.60),"confusion matrix -> 94.60% macro-F1",failures)
    extra,overall=additional_confusion_metrics(y_true,y_pred)
    check(close(overall["cohen_kappa"],0.912,0.001),"confusion matrix -> Cohen's kappa ~ 0.912",failures)
    check(close(overall["mcc"],0.912,0.001),"confusion matrix -> MCC ~ 0.912",failures)

    cv=pd.read_csv(ROOT/"reference"/"tableA1_cv_runs.csv")
    summary=pd.read_csv(ROOT/"reference"/"table7_cv_summary.csv").set_index("Statistic")
    for col in ["Accuracy (%)","Macro-P (%)","Macro-R (%)","Macro-F1 (%)"]:
        check(close(cv[col].mean(),summary.loc["Mean",col],0.015),f"Table A1 mean matches Table 7 for {col}",failures)
        check(close(cv[col].std(ddof=1),summary.loc["Standard deviation",col],0.015),f"Table A1 SD matches Table 7 for {col}",failures)
        check(close(cv[col].min(),summary.loc["Minimum",col],0.015),f"Table A1 minimum matches Table 7 for {col}",failures)
        check(close(cv[col].max(),summary.loc["Maximum",col],0.015),f"Table A1 maximum matches Table 7 for {col}",failures)
    # Every printed CV accuracy should be attainable (to rounding) with fold size 326 or 327.
    for val in cv["Accuracy (%)"]:
        possible=[]
        for n in [326,327]:
            for k in range(n+1): possible.append(100*k/n)
        check(min(abs(val-p) for p in possible)<0.011,f"CV accuracy {val:.2f}% is compatible with an integer count in a 326/327-record fold",failures)

    conv=pd.read_csv(ROOT/"reference"/"figure9_optimizer_convergence_illustrative.csv")
    for c in ["ESO","PSO","GA","Random_search"]:
        check(np.all(np.diff(conv[c].to_numpy())<=1e-12),f"illustrative {c} best-so-far convergence is non-increasing",failures)
    opt=pd.read_csv(ROOT/"reference"/"table9_optimizer_benchmark.csv").set_index("Optimizer")
    check(close(conv.ESO.iloc[-1],opt.loc["ESO (TeachEdge-ECL)","Best validation fitness"],1e-12),"illustrative ESO curve terminates at Table 9 fitness",failures)

    learn=pd.read_csv(ROOT/"reference"/"figure7_learning_curves_illustrative.csv")
    best_epoch=int(learn.loc[learn.validation_loss.idxmin(),"epoch"])
    check(best_epoch==36,"illustrative learning curve minimum validation loss is epoch 36",failures)
    check(int(learn.epoch.max())==46,"illustrative learning curve stops at epoch 46",failures)
    check(close(learn.loc[learn.epoch==36,"validation_loss"].iloc[0],0.1482,1e-12),"epoch-36 validation loss is 0.1482",failures)

    if failures:
        raise SystemExit(f"\n{len(failures)} verification check(s) failed.")
    print("\nAll arithmetic/reference checks passed.")


if __name__=="__main__": main()
