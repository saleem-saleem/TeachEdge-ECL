#!/usr/bin/env python
from __future__ import annotations

import argparse
from _bootstrap import setup_path
ROOT = setup_path()

from teachedge_ecl.config import load_config
from teachedge_ecl.data import load_canonical_dataset, split_dataset
from teachedge_ecl.evaluation import repeated_cv, cv_summary_table
from teachedge_ecl.io_utils import load_json, ensure_dir


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/paper.yaml")
    ap.add_argument("--paper-params", action="store_true")
    args = ap.parse_args()
    cfg = load_config(ROOT / args.config)
    if not args.paper_params and (ROOT / "artifacts" / "selected_hyperparameters.json").exists():
        hyper = load_json(ROOT / "artifacts" / "selected_hyperparameters.json")
    else:
        hyper = cfg["paper_selected_hyperparameters"]
    df, _, _ = load_canonical_dataset(cfg)
    bundle = split_dataset(df, cfg)
    cv = repeated_cv(bundle.development, cfg, hyper, fixed_epochs=cfg["validation"]["fixed_epochs"])
    out = ensure_dir(ROOT / "outputs" / "cv")
    cv.to_csv(out / "teachedge_cv_runs.csv", index=False)
    summary = cv_summary_table(cv)
    summary.to_csv(out / "teachedge_cv_summary.csv", index=False)
    print(cv.to_string(index=False))
    print("\n", summary.to_string(index=False))


if __name__ == "__main__":
    main()
