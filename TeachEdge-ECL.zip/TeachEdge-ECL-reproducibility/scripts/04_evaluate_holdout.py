#!/usr/bin/env python
from __future__ import annotations

import argparse
import numpy as np
import pandas as pd
import joblib
from _bootstrap import setup_path
ROOT = setup_path()

from teachedge_ecl.config import load_config
from teachedge_ecl.data import load_canonical_dataset, split_dataset, encode_labels
from teachedge_ecl.evaluation import evaluate_keras_model
from teachedge_ecl.metrics import classwise_table, additional_confusion_metrics
from teachedge_ecl.io_utils import ensure_dir, save_json


def main():
    import tensorflow as tf
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/paper.yaml")
    args = ap.parse_args()
    cfg = load_config(ROOT / args.config)
    model = tf.keras.models.load_model(ROOT / "artifacts" / "model.keras")
    prep = joblib.load(ROOT / "artifacts" / "preprocessor.joblib")
    df, _, _ = load_canonical_dataset(cfg)
    bundle = split_dataset(df, cfg)
    X = prep.transform(bundle.test)
    y = encode_labels(bundle.test["target"], cfg)
    summary, pred, probs = evaluate_keras_model(model, X, y, cfg["dataset"]["class_order"])
    out = ensure_dir(ROOT / "outputs" / "final")
    classwise_table(summary, cfg["dataset"]["class_order"]).to_csv(out / "holdout_classwise.csv", index=False)
    cm = pd.DataFrame(summary["confusion_matrix"], index=cfg["dataset"]["class_order"], columns=cfg["dataset"]["class_order"])
    cm.to_csv(out / "confusion_matrix.csv")
    extra_df, overall = additional_confusion_metrics(y, pred, cfg["dataset"]["class_order"])
    extra_df.to_csv(out / "additional_class_metrics.csv", index=False)
    save_json({
        "accuracy": summary["accuracy"],
        "macro_precision": summary["macro_precision"],
        "macro_recall": summary["macro_recall"],
        "macro_f1": summary["macro_f1"],
        **overall,
    }, out / "holdout_summary.json")
    pred_df = pd.DataFrame({
        "row_order": bundle.test["_row_order"].to_numpy(),
        "true_class": bundle.test["target"].to_numpy(),
        "predicted_class": [cfg["dataset"]["class_order"][i] for i in pred],
        "prob_low": probs[:, 0], "prob_medium": probs[:, 1], "prob_high": probs[:, 2],
    })
    pred_df.to_csv(out / "holdout_predictions.csv", index=False)
    print(classwise_table(summary, cfg["dataset"]["class_order"]).to_string(index=False))
    print("Additional overall:", overall)


if __name__ == "__main__":
    main()
