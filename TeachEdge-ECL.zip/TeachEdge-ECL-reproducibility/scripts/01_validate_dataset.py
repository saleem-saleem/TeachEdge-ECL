#!/usr/bin/env python
from __future__ import annotations

import argparse
from _bootstrap import setup_path
ROOT = setup_path()

from teachedge_ecl.config import load_config
from teachedge_ecl.data import load_canonical_dataset, split_dataset, class_counts
from teachedge_ecl.io_utils import sha256_file, save_json


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/paper.yaml")
    ap.add_argument("--strict", action="store_true", help="Fail if usable record count is not the paper count.")
    args = ap.parse_args()
    cfg = load_config(ROOT / args.config)
    df, mapping, path = load_canonical_dataset(cfg)
    bundle = split_dataset(df, cfg)
    print("Dataset:", path)
    print("SHA256:", sha256_file(path))
    print("Resolved columns:")
    for k, v in mapping.items():
        print(f"  {k:16s} <- {v}")
    print("\nUsable records:", len(df))
    print(class_counts(df, cfg).to_string(index=False))
    print(f"\nSplit sizes: train={len(bundle.train)}, validation={len(bundle.validation)}, "
          f"test={len(bundle.test)}, development={len(bundle.development)}")
    expected = int(cfg["dataset"]["expected_usable_records"])
    if len(df) != expected:
        msg = f"WARNING: manuscript expects {expected} usable records, but this file gives {len(df)} after cleaning."
        print(msg)
        if args.strict:
            raise SystemExit(msg)
    manifest = {
        "dataset": str(path),
        "sha256": sha256_file(path),
        "usable_records": len(df),
        "split_sizes": {"train": len(bundle.train), "validation": len(bundle.validation),
                        "test": len(bundle.test), "development": len(bundle.development)},
        "column_mapping": mapping,
    }
    save_json(manifest, ROOT / "outputs" / "dataset_manifest.json")


if __name__ == "__main__":
    main()
