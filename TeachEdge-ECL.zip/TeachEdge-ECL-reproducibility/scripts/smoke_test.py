#!/usr/bin/env python
"""Fast structural smoke test that does not claim paper performance.

It generates a small synthetic dataset with the same semantic columns, checks preprocessing,
model construction, one short training run, and the 610-budget arithmetic. It never writes into
reference/ and its metrics must not be used in the manuscript.
"""
from __future__ import annotations
import tempfile
from pathlib import Path
import numpy as np
import pandas as pd
from _bootstrap import setup_path
ROOT=setup_path()

from teachedge_ecl.config import load_config
from teachedge_ecl.preprocessing import TeachEdgePreprocessor
from teachedge_ecl.training import train_model, cleanup_model
from teachedge_ecl.data import encode_labels


def main():
    try:
        import tensorflow  # noqa: F401
    except ModuleNotFoundError:
        print('TensorFlow is not installed in this environment; structural pytest checks can still run. Install requirements.txt for the neural-network smoke test.')
        return
    cfg=load_config(ROOT/"configs"/"paper.yaml")
    rng=np.random.default_rng(42); n=120
    df=pd.DataFrame({"_row_order":np.arange(n),"age":rng.integers(24,60,n),"gender":rng.choice(["F","M"],n),"experience":rng.integers(1,30,n),"subject_stream":rng.choice(["Science","Arts","Commerce"],n),"attention":rng.random(n),"engagement":rng.random(n),"interaction":rng.random(n),"learning_gain":rng.random(n)})
    score=df[["attention","engagement","interaction","learning_gain"]].mean(axis=1)
    df["target"]=pd.cut(score,[-np.inf,.42,.62,np.inf],labels=["Low","Medium","High"]).astype(str)
    tr=df.iloc[:80].copy(); va=df.iloc[80:].copy(); prep=TeachEdgePreprocessor(cfg).fit(tr); Xtr,Xv=prep.transform(tr),prep.transform(va); ytr,yv=encode_labels(tr.target,cfg),encode_labels(va.target,cfg)
    cfg["training"]["max_epochs"]=2; cfg["training"]["early_stopping_patience"]=1
    hp=cfg["paper_selected_hyperparameters"]
    result=train_model(Xtr,ytr,Xv,yv,cfg,hp,seed=42); print(result.history.tail()); cleanup_model(result.model)
    assert cfg["eso"]["squads"]+3*cfg["eso"]["squads"]*cfg["eso"]["iterations"]==610
    print("Smoke test passed. Synthetic smoke-test metrics are not manuscript results.")


if __name__=="__main__": main()
