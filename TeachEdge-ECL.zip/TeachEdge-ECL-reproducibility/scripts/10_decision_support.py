#!/usr/bin/env python
from __future__ import annotations

import argparse, json
import joblib
import pandas as pd
from _bootstrap import setup_path
ROOT=setup_path()

from teachedge_ecl.config import load_config
from teachedge_ecl.data import load_canonical_dataset, split_dataset
from teachedge_ecl.decision_support import decision_support_for_dataframe
from teachedge_ecl.io_utils import ensure_dir


def main():
    import tensorflow as tf
    ap=argparse.ArgumentParser(); ap.add_argument("--config",default="configs/paper.yaml"); args=ap.parse_args()
    cfg=load_config(ROOT/args.config)
    model=tf.keras.models.load_model(ROOT/"artifacts"/"model.keras")
    prep=joblib.load(ROOT/"artifacts"/"preprocessor.joblib")
    df,_,_=load_canonical_dataset(cfg); bundle=split_dataset(df,cfg)
    imp_path=ROOT/"outputs"/"importance"/"permutation_importance.csv"
    if not imp_path.exists(): raise SystemExit("Run scripts/09_permutation_importance.py first.")
    imp=pd.read_csv(imp_path)
    ds=decision_support_for_dataframe(model,prep,bundle.test,cfg,importance=imp)
    ds["flags_json"]=ds["flags"].map(json.dumps); ds.drop(columns=["flags"]).to_csv(ensure_dir(ROOT/"outputs"/"decision_support")/"all_test_outputs.csv",index=False)
    share=(ds.assign(flagged=ds.n_flags>0).groupby("predicted_class").agg(records=("flagged","size"),flagged_records=("flagged","sum"),share_flagged=("flagged","mean")).reset_index())
    overall=pd.DataFrame([{"predicted_class":"Overall","records":len(ds),"flagged_records":int((ds.n_flags>0).sum()),"share_flagged":float((ds.n_flags>0).mean())}])
    share=pd.concat([share,overall],ignore_index=True); share["share_flagged_percent"]=100*share["share_flagged"]
    share.to_csv(ROOT/"outputs"/"decision_support"/"flagged_share_by_predicted_class.csv",index=False)
    print(share.to_string(index=False))


if __name__=="__main__": main()
