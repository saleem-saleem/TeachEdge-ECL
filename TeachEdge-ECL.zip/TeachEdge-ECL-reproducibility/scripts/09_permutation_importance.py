#!/usr/bin/env python
from __future__ import annotations

import argparse
import joblib
from _bootstrap import setup_path
ROOT=setup_path()

from teachedge_ecl.config import load_config
from teachedge_ecl.data import load_canonical_dataset, split_dataset
from teachedge_ecl.decision_support import permutation_importance_original_attributes
from teachedge_ecl.io_utils import ensure_dir


def main():
    import tensorflow as tf
    ap=argparse.ArgumentParser(); ap.add_argument("--config",default="configs/paper.yaml"); args=ap.parse_args()
    cfg=load_config(ROOT/args.config)
    model=tf.keras.models.load_model(ROOT/"artifacts"/"model.keras")
    prep=joblib.load(ROOT/"artifacts"/"preprocessor.joblib")
    df,_,_=load_canonical_dataset(cfg); bundle=split_dataset(df,cfg)
    imp=permutation_importance_original_attributes(model,prep,bundle.test,cfg)
    out=ensure_dir(ROOT/"outputs"/"importance"); imp.to_csv(out/"permutation_importance.csv",index=False)
    imp.to_csv(ROOT/"artifacts"/"feature_importance.csv",index=False)
    print(imp.to_string(index=False))


if __name__=="__main__": main()
