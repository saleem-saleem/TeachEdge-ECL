#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path
from _bootstrap import setup_path
ROOT = setup_path()

from teachedge_ecl.config import load_config
from teachedge_ecl.experiment import prepare_main_split, train_and_save_final
from teachedge_ecl.io_utils import load_json


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/paper.yaml")
    ap.add_argument("--paper-params", action="store_true", help="Use manuscript-selected params even if search output exists.")
    args = ap.parse_args()
    cfg = load_config(ROOT / args.config)
    search_file = ROOT / "outputs" / "search" / "eso_best.json"
    if not args.paper_params and search_file.exists():
        hyper = load_json(search_file)["best_params"]
        print("Using ESO output:", search_file)
    else:
        hyper = cfg["paper_selected_hyperparameters"]
        print("Using manuscript-selected hyperparameters from config.")
    prepared = prepare_main_split(cfg)
    result, manifest = train_and_save_final(
        prepared, cfg, hyper,
        artifact_dir=ROOT / "artifacts",
        output_dir=ROOT / "outputs" / "final",
    )
    print("Stopped epoch:", result.stopped_epoch)
    print("Restored/best epoch:", result.best_epoch)
    print("Minimum validation loss:", result.best_val_loss)
    print("Manifest:", manifest)


if __name__ == "__main__":
    main()
