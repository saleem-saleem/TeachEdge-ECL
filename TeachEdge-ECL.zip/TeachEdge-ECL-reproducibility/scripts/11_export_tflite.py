#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path
from _bootstrap import setup_path
ROOT=setup_path()

from teachedge_ecl.config import load_config
from teachedge_ecl.io_utils import save_json


def main():
    import tensorflow as tf
    ap=argparse.ArgumentParser(); ap.add_argument("--config",default="configs/paper.yaml"); args=ap.parse_args()
    cfg=load_config(ROOT/args.config)
    keras_path=ROOT/"artifacts"/"model.keras"
    if not keras_path.exists(): raise SystemExit("Run scripts/03_train_final.py first.")
    model=tf.keras.models.load_model(keras_path)
    converter=tf.lite.TFLiteConverter.from_keras_model(model)
    # Manuscript reports no quantization; retain float32 conversion.
    tflite=converter.convert()
    tflite_path=ROOT/"artifacts"/"model.tflite"
    tflite_path.write_bytes(tflite)
    related=[tflite_path, ROOT/"artifacts"/"preprocessor.joblib", ROOT/"artifacts"/"quartiles.json", ROOT/"artifacts"/"feature_importance.csv"]
    total=sum(p.stat().st_size for p in related if p.exists())/(1024**2)
    save_json({"tflite_model_bytes":len(tflite),"exported_bundle_mb":total,"files":[str(p.name) for p in related if p.exists()]}, ROOT/"artifacts"/"tflite_export_manifest.json")
    print(f"Wrote {tflite_path} ({len(tflite)/(1024**2):.2f} MB); bundle={total:.2f} MB")


if __name__=="__main__": main()
