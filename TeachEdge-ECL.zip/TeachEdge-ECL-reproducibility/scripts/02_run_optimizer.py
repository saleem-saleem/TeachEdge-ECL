#!/usr/bin/env python
from __future__ import annotations

import argparse
import copy
import time
from _bootstrap import setup_path
ROOT = setup_path()

from teachedge_ecl.config import load_config
from teachedge_ecl.experiment import prepare_main_split, make_search_objective
from teachedge_ecl.optimizers import (
    EgretSwarmOptimizer, ParticleSwarmOptimizer, GeneticAlgorithmOptimizer, RandomSearchOptimizer,
)
from teachedge_ecl.io_utils import ensure_dir, save_json


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/paper.yaml")
    ap.add_argument("--optimizer", choices=["eso", "pso", "ga", "random"], default="eso")
    ap.add_argument("--quick", action="store_true", help="Tiny smoke-test search; not paper-comparable.")
    args = ap.parse_args()
    cfg = load_config(ROOT / args.config)
    run_cfg = copy.deepcopy(cfg)
    if args.quick:
        run_cfg["training"]["max_epochs"] = 3
        run_cfg["training"]["early_stopping_patience"] = 2
        run_cfg["eso"]["squads"] = 2
        run_cfg["eso"]["iterations"] = 1
    prepared = prepare_main_split(run_cfg)
    objective = make_search_objective(prepared, run_cfg, quick=args.quick)
    budget = int(run_cfg["eso"]["squads"] + 3 * run_cfg["eso"]["squads"] * run_cfg["eso"]["iterations"])
    seed = int(run_cfg["project"]["seed"])
    if args.optimizer == "eso":
        opt = EgretSwarmOptimizer(run_cfg, seed=seed)
    elif args.optimizer == "pso":
        opt = ParticleSwarmOptimizer(run_cfg, seed=seed, budget=budget)
    elif args.optimizer == "ga":
        opt = GeneticAlgorithmOptimizer(run_cfg, seed=seed, budget=budget)
    else:
        opt = RandomSearchOptimizer(run_cfg, seed=seed, budget=budget)
    t0 = time.perf_counter()
    result = opt.run(objective)
    elapsed_h = (time.perf_counter() - t0) / 3600.0
    out = ensure_dir(ROOT / "outputs" / "search")
    prefix = f"{args.optimizer}{'_quick' if args.quick else ''}"
    result.log.to_csv(out / f"{prefix}_evaluations.csv", index=False)
    payload = {
        "optimizer": args.optimizer,
        "quick": args.quick,
        "best_fitness": result.best_fitness,
        "best_validation_macro_f1": 1.0 - result.best_fitness,
        "best_params": result.best_params,
        "evaluations": result.evaluations,
        "elapsed_hours": elapsed_h,
    }
    save_json(payload, out / f"{prefix}_best.json")
    print(payload)


if __name__ == "__main__":
    main()
