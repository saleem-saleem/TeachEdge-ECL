#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from _bootstrap import setup_path
ROOT=setup_path()

from teachedge_ecl.config import load_config
from teachedge_ecl.io_utils import ensure_dir, load_json


def savefig(path):
    plt.tight_layout(); plt.savefig(path,dpi=300,bbox_inches="tight"); plt.close()


def learning_curves(figdir, reference=False):
    p=ROOT/"outputs"/"final"/"training_history.csv"
    if not p.exists() and reference: p=ROOT/"reference"/"figure7_learning_curves_illustrative.csv"
    if not p.exists(): return
    d=pd.read_csv(p)
    loss_col="loss" if "loss" in d else "training_loss"; val_loss="val_loss" if "val_loss" in d else "validation_loss"
    acc="accuracy" if "accuracy" in d else "training_accuracy_percent"; val_acc="val_accuracy" if "val_accuracy" in d else "validation_accuracy_percent"
    scale=100 if d[acc].max()<=1.01 else 1
    best=int(d.loc[d[val_loss].idxmin(),"epoch"]); stop=int(d.epoch.max())
    plt.figure(figsize=(6,4)); plt.plot(d.epoch,d[loss_col],label="Training"); plt.plot(d.epoch,d[val_loss],label="Validation"); plt.axvline(best,ls="--",label=f"Restored epoch {best}"); plt.axvline(stop,ls=":",label=f"Stopping epoch {stop}"); plt.xlabel("Epoch"); plt.ylabel("Loss"); plt.legend(); savefig(figdir/"figure_learning_loss.png")
    plt.figure(figsize=(6,4)); plt.plot(d.epoch,d[acc]*scale,label="Training"); plt.plot(d.epoch,d[val_acc]*scale,label="Validation"); plt.axvline(best,ls="--"); plt.axvline(stop,ls=":"); plt.xlabel("Epoch"); plt.ylabel("Accuracy (%)"); plt.legend(); savefig(figdir/"figure_learning_accuracy.png")


def confusion(figdir, reference=False):
    p=ROOT/"outputs"/"final"/"confusion_matrix.csv"
    if p.exists(): cm=pd.read_csv(p,index_col=0).to_numpy(); labels=pd.read_csv(p,index_col=0).index.tolist()
    elif reference:
        r=pd.read_csv(ROOT/"reference"/"confusion_matrix.csv",index_col=0); cm=r.to_numpy(); labels=r.index.tolist()
    else: return
    plt.figure(figsize=(5,4)); plt.imshow(cm); plt.xticks(range(3),labels); plt.yticks(range(3),labels); plt.xlabel("Predicted"); plt.ylabel("True")
    for i in range(3):
        for j in range(3): plt.text(j,i,str(int(cm[i,j])),ha="center",va="center")
    savefig(figdir/"figure_confusion_matrix.png")


def convergence(figdir, reference=False):
    p=ROOT/"outputs"/"search"/"optimizer_convergence_checkpoints.csv"
    if not p.exists() and reference: p=ROOT/"reference"/"figure9_optimizer_convergence_illustrative.csv"
    if not p.exists(): return
    d=pd.read_csv(p); plt.figure(figsize=(6,4))
    for c in d.columns:
        if c not in ["evaluations","source_status"]: plt.plot(d.evaluations,d[c],marker="o",ms=3,label=c)
    plt.xlabel("Fitness evaluations"); plt.ylabel("Best validation fitness"); plt.legend(); savefig(figdir/"figure_optimizer_convergence.png")


def importance(figdir, reference=False):
    p=ROOT/"outputs"/"importance"/"permutation_importance.csv"
    if not p.exists() and reference: p=ROOT/"reference"/"table11_permutation_importance.csv"
    if not p.exists(): return
    d=pd.read_csv(p)
    attr="attribute" if "attribute" in d else "Attribute"; mean="mean_drop_macro_f1" if "mean_drop_macro_f1" in d else "Mean drop in macro-F1"; sd="sd" if "sd" in d else "SD"
    d=d.sort_values(mean,ascending=True); plt.figure(figsize=(7,4)); plt.barh(d[attr],d[mean],xerr=d[sd]); plt.xlabel("Mean drop in macro-F1"); savefig(figdir/"figure_permutation_importance.png")


def copy_tables(tabledir):
    sources={
        "table_holdout.csv":ROOT/"outputs"/"final"/"holdout_classwise.csv",
        "table_cv_runs.csv":ROOT/"outputs"/"cv"/"teachedge_cv_runs.csv",
        "table_cv_summary.csv":ROOT/"outputs"/"cv"/"teachedge_cv_summary.csv",
        "table_ablation.csv":ROOT/"outputs"/"ablation"/"ablation_summary.csv",
        "table_optimizer_benchmark.csv":ROOT/"outputs"/"search"/"optimizer_benchmark_summary.csv",
        "table_baselines.csv":ROOT/"outputs"/"baselines"/"baseline_summary.csv",
        "table_permutation_importance.csv":ROOT/"outputs"/"importance"/"permutation_importance.csv",
        "table_decision_support_share.csv":ROOT/"outputs"/"decision_support"/"flagged_share_by_predicted_class.csv",
    }
    for name,src in sources.items():
        if src.exists(): pd.read_csv(src).to_csv(tabledir/name,index=False)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--config",default="configs/paper.yaml"); ap.add_argument("--reference",action="store_true",help="Allow explicitly labelled reference/illustrative inputs when measured outputs are absent."); args=ap.parse_args()
    load_config(ROOT/args.config)
    figdir=ensure_dir(ROOT/"outputs"/"figures"); tabledir=ensure_dir(ROOT/"outputs"/"tables")
    learning_curves(figdir,args.reference); confusion(figdir,args.reference); convergence(figdir,args.reference); importance(figdir,args.reference); copy_tables(tabledir)
    print("Figures:",figdir); print("Tables:",tabledir)


if __name__=="__main__": main()
