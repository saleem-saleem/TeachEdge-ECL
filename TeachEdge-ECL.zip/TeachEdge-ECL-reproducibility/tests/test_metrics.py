import numpy as np
from teachedge_ecl.metrics import classification_summary, additional_confusion_metrics


def test_reference_confusion_matrix_metrics():
    cm=np.array([[33,0,2],[1,241,8],[1,7,115]])
    y_true=[]; y_pred=[]
    for i in range(3):
        for j in range(3):
            y_true += [i]*int(cm[i,j]); y_pred += [j]*int(cm[i,j])
    s=classification_summary(y_true,y_pred)
    assert len(y_true)==408
    assert sum(np.array(y_true)==np.array(y_pred))==389
    assert round(100*s['accuracy'],2)==95.34
    assert round(100*s['macro_precision'],2)==94.49
    assert round(100*s['macro_recall'],2)==94.73
    assert round(100*s['macro_f1'],2)==94.60
    _,o=additional_confusion_metrics(y_true,y_pred)
    assert round(o['cohen_kappa'],3)==0.912
    assert round(o['mcc'],3)==0.912
