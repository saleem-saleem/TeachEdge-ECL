from teachedge_ecl.config import load_config


def test_eso_budget_is_610():
    cfg=load_config('configs/paper.yaml')
    p=cfg['eso']['squads']; t=cfg['eso']['iterations']
    assert p+3*p*t==610
