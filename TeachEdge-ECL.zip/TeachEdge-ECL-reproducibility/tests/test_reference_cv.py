import pandas as pd


def test_tableA1_summary_matches_reference():
    cv=pd.read_csv('reference/tableA1_cv_runs.csv')
    summary=pd.read_csv('reference/table7_cv_summary.csv').set_index('Statistic')
    for c in ['Accuracy (%)','Macro-P (%)','Macro-R (%)','Macro-F1 (%)']:
        assert abs(cv[c].mean()-summary.loc['Mean',c])<0.015
        assert abs(cv[c].std(ddof=1)-summary.loc['Standard deviation',c])<0.015
        assert abs(cv[c].min()-summary.loc['Minimum',c])<0.015
        assert abs(cv[c].max()-summary.loc['Maximum',c])<0.015
