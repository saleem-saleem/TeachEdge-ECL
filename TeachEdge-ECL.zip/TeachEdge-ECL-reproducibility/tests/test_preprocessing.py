import numpy as np
import pandas as pd
from teachedge_ecl.config import load_config
from teachedge_ecl.preprocessing import TeachEdgePreprocessor


def tiny_df(n=20):
    rng=np.random.default_rng(1)
    return pd.DataFrame({
        '_row_order':np.arange(n),'age':rng.integers(25,60,n),'gender':rng.choice(['F','M'],n),
        'experience':rng.integers(1,30,n),'subject_stream':rng.choice(['A','B'],n),
        'attention':rng.random(n),'engagement':rng.random(n),'interaction':rng.random(n),'learning_gain':rng.random(n),
        'target':rng.choice(['Low','Medium','High'],n),
    })


def test_preprocessor_fits_only_supplied_training_rows():
    cfg=load_config('configs/paper.yaml')
    tr=tiny_df(20); te=tiny_df(5); te['age']=999
    p=TeachEdgePreprocessor(cfg).fit(tr)
    # Validation/test extremes are clipped and cannot change training scaler max.
    assert p.scaler.data_max_[0] < 999
    X=p.transform(te)
    assert np.isfinite(X).all()
