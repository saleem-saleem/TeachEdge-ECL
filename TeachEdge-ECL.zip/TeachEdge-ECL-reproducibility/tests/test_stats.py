import numpy as np
from teachedge_ecl.stats import corrected_resampled_ttest, holm_adjust


def test_holm_is_monotone_in_sorted_order():
    p=np.array([0.01,0.04,0.001,0.2])
    adj=holm_adjust(p)
    assert np.all(adj>=p)
    assert np.all(adj<=1)
    order=np.argsort(p)
    assert np.all(np.diff(adj[order])>=-1e-15)


def test_corrected_resampled_ttest_zero_difference():
    x=np.array([0.9,0.91,0.92,0.93,0.94])
    r=corrected_resampled_ttest(x,x,train_size=4,test_size=1)
    assert r['mean_difference']==0
    assert r['p_raw']==1
