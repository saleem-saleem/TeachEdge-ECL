from teachedge_ecl.config import load_config
from teachedge_ecl.models import selected_filters
from teachedge_ecl.optimizers.common import SearchSpace


def test_selected_filters():
    cfg=load_config('configs/paper.yaml')
    assert selected_filters(cfg,1.25)==[80,160,320]


def test_decode_paper_candidate():
    cfg=load_config('configs/paper.yaml'); space=SearchSpace(cfg)
    x=space.encode(cfg['paper_selected_hyperparameters']); d=space.decode(x)
    assert d['batch_size']==32
    assert d['lstm_units']==192
    assert abs(d['learning_rate']-0.0008)<1e-12
