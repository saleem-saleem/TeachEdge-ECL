from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import copy
import time
import numpy as np
import pandas as pd
import joblib
from sklearn.metrics import f1_score

from .data import load_canonical_dataset, split_dataset, encode_labels
from .preprocessing import TeachEdgePreprocessor
from .training import train_model, predict_probabilities, cleanup_model
from .seed import set_global_seed
from .io_utils import ensure_dir, save_json


@dataclass
class MainSplitPrepared:
    dataframe: pd.DataFrame
    bundle: Any
    preprocessor: TeachEdgePreprocessor
    X_train: np.ndarray
    X_validation: np.ndarray
    X_test: np.ndarray
    y_train: np.ndarray
    y_validation: np.ndarray
    y_test: np.ndarray
    dataset_path: Path
    column_mapping: dict[str, str]


def prepare_main_split(cfg: dict, use_sg: bool = True, use_pca: bool = True) -> MainSplitPrepared:
    df, mapping, dataset_path = load_canonical_dataset(cfg)
    bundle = split_dataset(df, cfg, seed=cfg["project"]["seed"])
    prep = TeachEdgePreprocessor(cfg, use_sg=use_sg, use_pca=use_pca).fit(bundle.train)
    return MainSplitPrepared(
        dataframe=df,
        bundle=bundle,
        preprocessor=prep,
        X_train=prep.transform(bundle.train),
        X_validation=prep.transform(bundle.validation),
        X_test=prep.transform(bundle.test),
        y_train=encode_labels(bundle.train["target"], cfg),
        y_validation=encode_labels(bundle.validation["target"], cfg),
        y_test=encode_labels(bundle.test["target"], cfg),
        dataset_path=dataset_path,
        column_mapping=mapping,
    )


def make_search_objective(prepared: MainSplitPrepared, cfg: dict, variant: str = "full", quick: bool = False):
    """Return expensive black-box objective: 1 - validation macro-F1."""
    local_cfg = copy.deepcopy(cfg)
    if quick:
        local_cfg["training"]["max_epochs"] = min(3, int(local_cfg["training"]["max_epochs"]))
        local_cfg["training"]["early_stopping_patience"] = min(2, int(local_cfg["training"]["early_stopping_patience"]))

    def objective(params: dict[str, Any], eval_no: int) -> float:
        # Distinct deterministic seed per evaluation while preserving repeatability.
        seed = int(cfg["project"]["seed"]) + int(eval_no)
        result = train_model(
            prepared.X_train, prepared.y_train,
            prepared.X_validation, prepared.y_validation,
            local_cfg, params, variant=variant, seed=seed,
        )
        probs = predict_probabilities(result.model, prepared.X_validation)
        pred = probs.argmax(axis=1)
        macro_f1 = f1_score(prepared.y_validation, pred, average="macro")
        cleanup_model(result.model)
        return float(1.0 - macro_f1)
    return objective


def train_and_save_final(
    prepared: MainSplitPrepared,
    cfg: dict,
    hyperparams: dict,
    variant: str = "full",
    artifact_dir: str | Path = "artifacts",
    output_dir: str | Path = "outputs/final",
):
    artifact_dir = ensure_dir(artifact_dir)
    output_dir = ensure_dir(output_dir)
    result = train_model(
        prepared.X_train, prepared.y_train,
        prepared.X_validation, prepared.y_validation,
        cfg, hyperparams, variant=variant, seed=int(cfg["project"]["seed"]),
    )
    model_path = artifact_dir / "model.keras"
    result.model.save(model_path)
    joblib.dump(prepared.preprocessor, artifact_dir / "preprocessor.joblib")
    result.history.to_csv(output_dir / "training_history.csv", index=False)
    save_json(hyperparams, artifact_dir / "selected_hyperparameters.json")
    save_json(prepared.preprocessor.quartiles_scaled, artifact_dir / "quartiles.json")
    manifest = {
        "dataset_path": str(prepared.dataset_path),
        "n_total": len(prepared.dataframe),
        "n_train": len(prepared.bundle.train),
        "n_validation": len(prepared.bundle.validation),
        "n_test": len(prepared.bundle.test),
        "pca_components": prepared.preprocessor.retained_components,
        "pca_explained_variance": prepared.preprocessor.explained_variance,
        "stopped_epoch": result.stopped_epoch,
        "best_epoch": result.best_epoch,
        "best_val_loss": result.best_val_loss,
        "column_mapping": prepared.column_mapping,
    }
    save_json(manifest, artifact_dir / "manifest.json")
    return result, manifest
