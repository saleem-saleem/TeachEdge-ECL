from __future__ import annotations

import numpy as np
from scipy import stats


def corrected_resampled_ttest(
    reference_scores,
    comparison_scores,
    train_size: float,
    test_size: float,
) -> dict:
    """Nadeau-Bengio corrected resampled t-test on paired scores.

    `reference_scores` and `comparison_scores` must be paired in identical repeat/fold order.
    The returned mean_difference is reference - comparison, so positive values favor reference.
    """
    a = np.asarray(reference_scores, dtype=float)
    b = np.asarray(comparison_scores, dtype=float)
    if a.shape != b.shape:
        raise ValueError("Paired score arrays must have the same shape")
    if a.ndim != 1 or len(a) < 2:
        raise ValueError("At least two paired runs are required")
    d = a - b
    n = len(d)
    mean = float(np.mean(d))
    var = float(np.var(d, ddof=1))
    correction = 1.0 / n + float(test_size) / float(train_size)
    se = float(np.sqrt(correction * var))
    if se == 0:
        t = np.inf if mean != 0 else 0.0
        p = 0.0 if mean != 0 else 1.0
    else:
        t = mean / se
        p = 2.0 * stats.t.sf(abs(t), df=n - 1)
    crit = stats.t.ppf(0.975, df=n - 1)
    ci = (mean - crit * se, mean + crit * se)
    return {
        "mean_difference": mean,
        "sd_difference": float(np.std(d, ddof=1)),
        "standard_error_corrected": se,
        "t": float(t),
        "df": n - 1,
        "p_raw": float(p),
        "ci95_low": float(ci[0]),
        "ci95_high": float(ci[1]),
    }


def holm_adjust(p_values):
    """Holm step-down family-wise-error correction."""
    p = np.asarray(p_values, dtype=float)
    m = len(p)
    order = np.argsort(p)
    adjusted_sorted = np.empty(m, dtype=float)
    running = 0.0
    for rank, idx in enumerate(order):
        candidate = (m - rank) * p[idx]
        running = max(running, candidate)
        adjusted_sorted[rank] = min(1.0, running)
    adjusted = np.empty(m, dtype=float)
    for rank, idx in enumerate(order):
        adjusted[idx] = adjusted_sorted[rank]
    return adjusted
