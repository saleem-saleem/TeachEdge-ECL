from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import f1_score

from .data import CLASSROOM_INDICATORS, TARGET, encode_labels
from .training import predict_probabilities


def permutation_importance_original_attributes(
    model,
    preprocessor,
    test_df: pd.DataFrame,
    cfg: dict,
    repetitions: int | None = None,
    seed: int | None = None,
) -> pd.DataFrame:
    """Permutation importance on original columns before PCA.

    The full fitted preprocessing path is re-run after each original attribute is shuffled.
    """
    repetitions = int(repetitions or cfg["permutation_importance"]["repetitions"])
    seed = int(seed if seed is not None else cfg["permutation_importance"]["seed"])
    rng = np.random.default_rng(seed)
    y = encode_labels(test_df[TARGET], cfg)
    X = preprocessor.transform(test_df)
    base_pred = predict_probabilities(model, X).argmax(axis=1)
    baseline = f1_score(y, base_pred, average="macro")
    attrs = ["age", "gender", "experience", "subject_stream", *CLASSROOM_INDICATORS]
    rows = []
    for attr in attrs:
        drops = []
        values = test_df[attr].to_numpy(copy=True)
        for _ in range(repetitions):
            shuffled = test_df.copy()
            shuffled[attr] = rng.permutation(values)
            pred = predict_probabilities(model, preprocessor.transform(shuffled)).argmax(axis=1)
            score = f1_score(y, pred, average="macro")
            drops.append(baseline - score)
        rows.append({
            "attribute": attr,
            "mean_drop_macro_f1": float(np.mean(drops)),
            "sd": float(np.std(drops, ddof=1)),
            "repetitions": repetitions,
        })
    return pd.DataFrame(rows).sort_values("mean_drop_macro_f1", ascending=False).reset_index(drop=True)


def decision_support_for_dataframe(
    model,
    preprocessor,
    df: pd.DataFrame,
    importance: pd.DataFrame,
    cfg: dict,
) -> pd.DataFrame:
    X = preprocessor.transform(df)
    probs = predict_probabilities(model, X)
    pred = probs.argmax(axis=1)
    class_order = cfg["dataset"]["class_order"]
    scaled = preprocessor.scaled_indicator_values(df)
    importance_map = dict(zip(importance["attribute"], importance["mean_drop_macro_f1"]))
    rows = []
    for i, (_, row) in enumerate(df.reset_index(drop=True).iterrows()):
        flags = []
        for indicator in CLASSROOM_INDICATORS:
            value = float(scaled.iloc[i][indicator])
            threshold = float(preprocessor.quartiles_scaled[indicator])
            important = importance_map.get(indicator, 0.0) > 0 if cfg["decision_support"]["require_positive_importance"] else True
            if important and value < threshold:
                flags.append({"indicator": indicator, "value": value, "threshold": threshold,
                              "importance": float(importance_map.get(indicator, 0.0))})
        flags.sort(key=lambda x: x["importance"], reverse=True)
        rows.append({
            "row_order": int(row["_row_order"]),
            "true_class": row[TARGET],
            "predicted_class": class_order[int(pred[i])],
            "probability": float(probs[i, pred[i]]),
            "flags": flags,
            "n_flags": len(flags),
        })
    return pd.DataFrame(rows)
