from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold

from .data import encode_labels, TARGET
from .preprocessing import TeachEdgePreprocessor
from .training import train_model, predict_probabilities, cleanup_model
from .metrics import classification_summary


@dataclass
class CVRun:
    seed: int
    fold: int
    accuracy: float
    macro_precision: float
    macro_recall: float
    macro_f1: float
    n_train: int
    n_test: int


def evaluate_keras_model(model, X, y, class_names=("Low", "Medium", "High")) -> tuple[dict, np.ndarray, np.ndarray]:
    probs = predict_probabilities(model, X)
    pred = probs.argmax(axis=1)
    return classification_summary(y, pred, class_names), pred, probs


def repeated_cv(
    development_df: pd.DataFrame,
    cfg: dict,
    hyperparams: dict,
    variant: str = "full",
    use_sg: bool = True,
    use_pca: bool = True,
    fixed_epochs: int | None = None,
) -> pd.DataFrame:
    fixed_epochs = int(fixed_epochs or cfg["validation"]["fixed_epochs"])
    y_all = encode_labels(development_df[TARGET], cfg)
    rows = []
    for seed in cfg["validation"]["repeat_seeds"]:
        skf = StratifiedKFold(n_splits=int(cfg["validation"]["folds"]), shuffle=True, random_state=int(seed))
        for fold, (train_idx, test_idx) in enumerate(skf.split(development_df, y_all), start=1):
            tr = development_df.iloc[train_idx].sort_values("_row_order").reset_index(drop=True)
            te = development_df.iloc[test_idx].sort_values("_row_order").reset_index(drop=True)
            prep = TeachEdgePreprocessor(cfg, use_sg=use_sg, use_pca=use_pca).fit(tr)
            Xtr, Xte = prep.transform(tr), prep.transform(te)
            ytr = encode_labels(tr[TARGET], cfg)
            yte = encode_labels(te[TARGET], cfg)
            result = train_model(
                Xtr, ytr, None, None, cfg, hyperparams,
                variant=variant, seed=int(seed) * 100 + fold,
                fixed_epochs=fixed_epochs,
            )
            summary, _, _ = evaluate_keras_model(result.model, Xte, yte, cfg["dataset"]["class_order"])
            rows.append({
                "Seed": int(seed),
                "Fold": int(fold),
                "Accuracy (%)": 100 * summary["accuracy"],
                "Macro-P (%)": 100 * summary["macro_precision"],
                "Macro-R (%)": 100 * summary["macro_recall"],
                "Macro-F1 (%)": 100 * summary["macro_f1"],
                "n_train": len(tr),
                "n_test": len(te),
            })
            cleanup_model(result.model)
    return pd.DataFrame(rows)


def cv_summary_table(cv_df: pd.DataFrame, holdout: dict | None = None) -> pd.DataFrame:
    metrics = ["Accuracy (%)", "Macro-P (%)", "Macro-R (%)", "Macro-F1 (%)"]
    rows = []
    rows.append({"Statistic": "Mean", **{m: cv_df[m].mean() for m in metrics}})
    rows.append({"Statistic": "Standard deviation", **{m: cv_df[m].std(ddof=1) for m in metrics}})
    rows.append({"Statistic": "Minimum", **{m: cv_df[m].min() for m in metrics}})
    rows.append({"Statistic": "Maximum", **{m: cv_df[m].max() for m in metrics}})
    if holdout is not None:
        rows.append({
            "Statistic": "Hold-out test",
            "Accuracy (%)": 100 * holdout["accuracy"],
            "Macro-P (%)": 100 * holdout["macro_precision"],
            "Macro-R (%)": 100 * holdout["macro_recall"],
            "Macro-F1 (%)": 100 * holdout["macro_f1"],
        })
    return pd.DataFrame(rows)
