from __future__ import annotations

import os
import time
from pathlib import Path
import numpy as np
import psutil


def load_tflite_interpreter(path: str | Path, backend: str = "auto"):
    path = str(path)
    errors = []
    if backend in ("auto", "tensorflow"):
        try:
            import tensorflow as tf
            interpreter = tf.lite.Interpreter(model_path=path)
            interpreter.allocate_tensors()
            return interpreter, "tensorflow.lite"
        except Exception as e:
            errors.append(repr(e))
    if backend in ("auto", "tflite_runtime"):
        try:
            from tflite_runtime.interpreter import Interpreter
            interpreter = Interpreter(model_path=path)
            interpreter.allocate_tensors()
            return interpreter, "tflite_runtime"
        except Exception as e:
            errors.append(repr(e))
    raise RuntimeError("Could not load a TensorFlow Lite interpreter: " + " | ".join(errors))


def tflite_predict(interpreter, X_seq: np.ndarray) -> np.ndarray:
    input_details = interpreter.get_input_details()[0]
    output_details = interpreter.get_output_details()[0]
    X_seq = np.asarray(X_seq, dtype=input_details["dtype"])
    outputs = []
    for row in X_seq:
        batch = row[None, ...]
        expected_shape = tuple(input_details["shape"])
        if expected_shape[0] != 1 or tuple(batch.shape) != expected_shape:
            interpreter.resize_tensor_input(input_details["index"], batch.shape, strict=False)
            interpreter.allocate_tensors()
            input_details = interpreter.get_input_details()[0]
            output_details = interpreter.get_output_details()[0]
        interpreter.set_tensor(input_details["index"], batch)
        interpreter.invoke()
        outputs.append(interpreter.get_tensor(output_details["index"])[0])
    return np.asarray(outputs)


def benchmark_callable(single_record_fn, batch_fn=None, warmup: int = 50, timed: int = 1000,
                       batch_size: int = 256, batches: int = 100) -> dict:
    for _ in range(warmup):
        single_record_fn()
    latencies_ms = []
    process = psutil.Process(os.getpid())
    peak_rss = process.memory_info().rss
    for _ in range(timed):
        t0 = time.perf_counter_ns()
        single_record_fn()
        t1 = time.perf_counter_ns()
        latencies_ms.append((t1 - t0) / 1e6)
        peak_rss = max(peak_rss, process.memory_info().rss)
    throughput = None
    if batch_fn is not None:
        t0 = time.perf_counter()
        total = 0
        for _ in range(batches):
            batch_fn(batch_size)
            total += batch_size
        elapsed = time.perf_counter() - t0
        throughput = total / elapsed
    arr = np.asarray(latencies_ms)
    return {
        "latency_mean_ms": float(arr.mean()),
        "latency_sd_ms": float(arr.std(ddof=1)),
        "latency_p95_ms": float(np.percentile(arr, 95)),
        "peak_memory_mb": float(peak_rss / (1024 ** 2)),
        "throughput_records_per_s": None if throughput is None else float(throughput),
    }
