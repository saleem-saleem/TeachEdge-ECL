from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score, precision_recall_fscore_support, confusion_matrix,
    cohen_kappa_score, matthews_corrcoef,
)


def classification_summary(y_true, y_pred, class_names=("Low", "Medium", "High")) -> dict:
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true, y_pred, labels=np.arange(len(class_names)), zero_division=0
    )
    accuracy = accuracy_score(y_true, y_pred)
    cm = confusion_matrix(y_true, y_pred, labels=np.arange(len(class_names)))
    return {
        "accuracy": float(accuracy),
        "macro_precision": float(np.mean(precision)),
        "macro_recall": float(np.mean(recall)),
        "macro_f1": float(np.mean(f1)),
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "support": support,
        "confusion_matrix": cm,
    }


def classwise_table(summary: dict, class_names=("Low", "Medium", "High")) -> pd.DataFrame:
    rows = []
    for i, name in enumerate(class_names):
        rows.append({
            "Class": name,
            "Precision (%)": 100 * summary["precision"][i],
            "Recall (%)": 100 * summary["recall"][i],
            "F1-score (%)": 100 * summary["f1"][i],
            "Support (records)": int(summary["support"][i]),
        })
    rows.append({
        "Class": "Macro average",
        "Precision (%)": 100 * summary["macro_precision"],
        "Recall (%)": 100 * summary["macro_recall"],
        "F1-score (%)": 100 * summary["macro_f1"],
        "Support (records)": int(np.sum(summary["support"])),
    })
    rows.append({
        "Class": "Accuracy (%)",
        "Precision (%)": 100 * summary["accuracy"],
        "Recall (%)": np.nan,
        "F1-score (%)": np.nan,
        "Support (records)": int(np.sum(summary["support"])),
    })
    return pd.DataFrame(rows)


def additional_confusion_metrics(y_true, y_pred, class_names=("Low", "Medium", "High")) -> tuple[pd.DataFrame, dict]:
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    cm = confusion_matrix(y_true, y_pred, labels=np.arange(len(class_names)))
    n = cm.sum()
    rows = []
    recalls = []
    for i, name in enumerate(class_names):
        tp = cm[i, i]
        fn = cm[i, :].sum() - tp
        fp = cm[:, i].sum() - tp
        tn = n - tp - fn - fp
        specificity = tn / (tn + fp) if tn + fp else np.nan
        miss = fn / (tp + fn) if tp + fn else np.nan
        npv = tn / (tn + fn) if tn + fn else np.nan
        recall = tp / (tp + fn) if tp + fn else np.nan
        recalls.append(recall)
        rows.append({
            "Class": name,
            "Specificity (%)": 100 * specificity,
            "Miss rate (%)": 100 * miss,
            "Negative predictive value (%)": 100 * npv,
        })
    overall = {
        "cohen_kappa": float(cohen_kappa_score(y_true, y_pred)),
        "mcc": float(matthews_corrcoef(y_true, y_pred)),
        "balanced_accuracy": float(np.nanmean(recalls)),
    }
    return pd.DataFrame(rows), overall
