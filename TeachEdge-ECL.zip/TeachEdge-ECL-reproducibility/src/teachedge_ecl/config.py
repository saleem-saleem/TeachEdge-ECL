from __future__ import annotations

from pathlib import Path
from typing import Any
import yaml


def load_config(path: str | Path = "configs/paper.yaml") -> dict[str, Any]:
    path = Path(path)
    with path.open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    cfg["_config_path"] = str(path.resolve())
    return cfg


def project_path(cfg: dict[str, Any], *parts: str) -> Path:
    base = Path(cfg["_config_path"]).resolve().parent.parent
    return base.joinpath(*parts)
