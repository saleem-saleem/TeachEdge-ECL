"""TeachEdge-ECL reproducibility package."""

__version__ = "0.1.0"
