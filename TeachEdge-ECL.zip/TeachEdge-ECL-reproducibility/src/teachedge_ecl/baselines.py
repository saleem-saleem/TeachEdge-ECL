from __future__ import annotations

from itertools import product
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import f1_score


def _xgb():
    from xgboost import XGBClassifier
    return XGBClassifier


def baseline_grids(seed: int = 42):
    return {
        "Decision tree": [
            DecisionTreeClassifier(random_state=seed, max_depth=d, min_samples_leaf=l)
            for d in [None, 5, 10, 20] for l in [1, 3, 5]
        ],
        "Random forest": [
            RandomForestClassifier(random_state=seed, n_jobs=-1, n_estimators=n, max_depth=d,
                                   min_samples_leaf=l, class_weight="balanced")
            for n in [200, 500] for d in [None, 10, 20] for l in [1, 3]
        ],
        "SVM": [
            SVC(C=c, gamma=g, kernel="rbf", probability=True, class_weight="balanced", random_state=seed)
            for c in [0.5, 1.0, 5.0, 10.0] for g in ["scale", 0.01, 0.1]
        ],
        "ANN": [
            MLPClassifier(hidden_layer_sizes=h, alpha=a, learning_rate_init=lr, max_iter=500,
                          random_state=seed, early_stopping=True, validation_fraction=0.15)
            for h in [(64,), (128,), (128, 64)] for a in [1e-4, 1e-3] for lr in [1e-3, 5e-4]
        ],
        "XGBoost": [
            _xgb()(n_estimators=n, max_depth=d, learning_rate=lr, subsample=0.9,
                   colsample_bytree=0.9, objective="multi:softprob", eval_metric="mlogloss",
                   random_state=seed, n_jobs=-1)
            for n in [200, 400] for d in [3, 5] for lr in [0.03, 0.08]
        ],
    }


def tune_sklearn_baseline(name, X_train, y_train, X_val, y_val, seed=42):
    candidates = baseline_grids(seed)[name]
    best_model, best_score = None, -np.inf
    rows = []
    for i, model in enumerate(candidates, start=1):
        model.fit(X_train, y_train)
        pred = model.predict(X_val)
        score = f1_score(y_val, pred, average="macro")
        rows.append({"candidate": i, "validation_macro_f1": score, "repr": repr(model)})
        if score > best_score:
            best_model, best_score = model, score
    return best_model, best_score, rows
