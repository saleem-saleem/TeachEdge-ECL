from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split


CANONICAL_FEATURES = [
    "age", "gender", "experience", "subject_stream",
    "attention", "engagement", "interaction", "learning_gain",
]
ID_COLUMNS = ["student_id", "teacher_id"]
CLASSROOM_INDICATORS = ["attention", "engagement", "interaction", "learning_gain"]
NUMERIC_FEATURES = ["age", "experience", *CLASSROOM_INDICATORS]
CATEGORICAL_FEATURES = ["gender", "subject_stream"]
TARGET = "target"


@dataclass
class DatasetBundle:
    full: pd.DataFrame
    train: pd.DataFrame
    validation: pd.DataFrame
    test: pd.DataFrame
    development: pd.DataFrame
    column_mapping: dict[str, str]


def _norm_name(name: str) -> str:
    name = str(name).strip().lower()
    name = re.sub(r"[^a-z0-9]+", "_", name)
    return name.strip("_")


def resolve_dataset_file(cfg: dict) -> Path:
    explicit = cfg["dataset"].get("file")
    root = Path(cfg["_config_path"]).resolve().parent.parent
    if explicit:
        p = Path(explicit)
        if not p.is_absolute():
            p = root / p
        if not p.exists():
            raise FileNotFoundError(f"Configured dataset file does not exist: {p}")
        return p
    candidates = sorted((root / "data" / "raw").glob("**/*.csv"))
    if not candidates:
        raise FileNotFoundError(
            "No CSV found under data/raw/. Run scripts/00_download_data.py or set dataset.file in configs/paper.yaml."
        )
    if len(candidates) > 1:
        # Prefer filenames containing teacher/effectiveness, otherwise largest CSV.
        preferred = [p for p in candidates if "teacher" in p.name.lower() or "effect" in p.name.lower()]
        if preferred:
            return preferred[0]
        return max(candidates, key=lambda p: p.stat().st_size)
    return candidates[0]


def resolve_columns(df: pd.DataFrame, cfg: dict) -> dict[str, str]:
    aliases = cfg["dataset"]["aliases"]
    normalized_actual = {_norm_name(c): c for c in df.columns}
    mapping: dict[str, str] = {}
    for canonical, alias_list in aliases.items():
        for candidate in [canonical, *alias_list]:
            key = _norm_name(candidate)
            if key in normalized_actual:
                mapping[canonical] = normalized_actual[key]
                break
    required = [*CANONICAL_FEATURES, TARGET]
    missing = [x for x in required if x not in mapping]
    if missing:
        raise ValueError(
            "Could not resolve required semantic columns: " + ", ".join(missing) +
            ". Edit dataset.aliases in configs/paper.yaml. Available columns: " + ", ".join(map(str, df.columns))
        )
    return mapping


def canonicalize_dataframe(raw: pd.DataFrame, cfg: dict) -> tuple[pd.DataFrame, dict[str, str]]:
    mapping = resolve_columns(raw, cfg)
    keep = {canon: raw_col for canon, raw_col in mapping.items() if canon in [*ID_COLUMNS, *CANONICAL_FEATURES, TARGET]}
    out = pd.DataFrame(index=raw.index)
    out["_row_order"] = np.arange(len(raw), dtype=int)
    for canon, raw_col in keep.items():
        out[canon] = raw[raw_col]

    # IDs are allowed to be unresolved; features/target are not.
    for col in NUMERIC_FEATURES:
        out[col] = pd.to_numeric(out[col], errors="coerce")

    # Standardize target labels. Numeric 0/1/2 is accepted as Low/Medium/High.
    class_order = cfg["dataset"]["class_order"]
    numeric_map = {0: class_order[0], 1: class_order[1], 2: class_order[2],
                   "0": class_order[0], "1": class_order[1], "2": class_order[2]}
    def normalize_target(v):
        if pd.isna(v):
            return np.nan
        if v in numeric_map:
            return numeric_map[v]
        s = str(v).strip().lower()
        for label in class_order:
            if s == label.lower():
                return label
        return str(v).strip()
    out[TARGET] = out[TARGET].map(normalize_target)

    # Remove incomplete records and duplicates exactly once before splitting.
    subset = [*CANONICAL_FEATURES, TARGET]
    out = out.dropna(subset=subset)
    out = out.drop_duplicates(subset=subset, keep="first")
    out = out.sort_values("_row_order").reset_index(drop=True)

    unknown = sorted(set(out[TARGET].unique()) - set(class_order))
    if unknown:
        raise ValueError(f"Unexpected target labels after normalization: {unknown}; expected {class_order}")
    return out, mapping


def load_canonical_dataset(cfg: dict) -> tuple[pd.DataFrame, dict[str, str], Path]:
    path = resolve_dataset_file(cfg)
    raw = pd.read_csv(path)
    df, mapping = canonicalize_dataframe(raw, cfg)
    return df, mapping, path


def split_dataset(df: pd.DataFrame, cfg: dict, seed: int | None = None) -> DatasetBundle:
    seed = cfg["project"]["seed"] if seed is None else int(seed)
    y = df[TARGET]
    test_fraction = float(cfg["split"]["test_fraction"])
    dev, test = train_test_split(
        df, test_size=test_fraction, random_state=seed, stratify=y, shuffle=True
    )
    # Validation is 20% of total => 25% of 80% development.
    val_total = float(cfg["split"]["validation_fraction_total"])
    val_within_dev = val_total / (1.0 - test_fraction)
    train, validation = train_test_split(
        dev, test_size=val_within_dev, random_state=seed, stratify=dev[TARGET], shuffle=True
    )
    # Restore original order inside each subset before the SG filter is applied.
    sort = lambda x: x.sort_values("_row_order").reset_index(drop=True)
    train, validation, test, dev = map(sort, [train, validation, test, dev])
    return DatasetBundle(
        full=df.copy(), train=train, validation=validation, test=test, development=dev,
        column_mapping={}
    )


def encode_labels(series: pd.Series, cfg: dict) -> np.ndarray:
    mapping = {label: i for i, label in enumerate(cfg["dataset"]["class_order"])}
    return series.map(mapping).to_numpy(dtype=np.int64)


def class_counts(df: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    order = cfg["dataset"]["class_order"]
    counts = df[TARGET].value_counts().reindex(order, fill_value=0)
    result = pd.DataFrame({"class": order, "count": counts.values})
    result["proportion"] = result["count"] / len(df)
    return result
