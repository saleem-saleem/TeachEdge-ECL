from __future__ import annotations

import os
import random
import numpy as np


def set_global_seed(seed: int, deterministic_ops: bool = True) -> None:
    os.environ["PYTHONHASHSEED"] = str(seed)
    if deterministic_ops:
        os.environ.setdefault("TF_DETERMINISTIC_OPS", "1")
        os.environ.setdefault("TF_CUDNN_DETERMINISTIC", "1")
    random.seed(seed)
    np.random.seed(seed)
    try:
        import tensorflow as tf
        tf.keras.utils.set_random_seed(seed)
        if deterministic_ops:
            try:
                tf.config.experimental.enable_op_determinism()
            except Exception:
                pass
    except Exception:
        # Allows data/statistical utilities to run without TensorFlow imported.
        pass
