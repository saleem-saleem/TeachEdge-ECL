from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
import numpy as np
import pandas as pd
from scipy.signal import savgol_filter
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder
from sklearn.decomposition import PCA

from .data import (
    NUMERIC_FEATURES, CATEGORICAL_FEATURES, CLASSROOM_INDICATORS,
)


@dataclass
class TeachEdgePreprocessor:
    cfg: dict[str, Any]
    use_sg: bool = True
    use_pca: bool = True
    scaler: MinMaxScaler | None = None
    encoder: OneHotEncoder | None = None
    pca: PCA | None = None
    feature_names_before_pca: list[str] = field(default_factory=list)
    quartiles_scaled: dict[str, float] = field(default_factory=dict)

    def fit(self, train_df: pd.DataFrame) -> "TeachEdgePreprocessor":
        lo, hi = self.cfg["preprocessing"]["minmax_range"]
        self.scaler = MinMaxScaler(feature_range=(float(lo), float(hi)), clip=True)
        self.scaler.fit(train_df[NUMERIC_FEATURES])

        self.encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False, dtype=np.float32)
        self.encoder.fit(train_df[CATEGORICAL_FEATURES].astype(str))

        numeric_scaled = self.scaler.transform(train_df[NUMERIC_FEATURES])
        idx = {name: i for i, name in enumerate(NUMERIC_FEATURES)}
        self.quartiles_scaled = {
            name: float(np.quantile(numeric_scaled[:, idx[name]], self.cfg["decision_support"]["flag_quantile"]))
            for name in CLASSROOM_INDICATORS
        }

        matrix, names = self._compose(train_df, fit_stage=True)
        self.feature_names_before_pca = names
        if self.use_pca and self.cfg["preprocessing"]["pca"]["enabled"]:
            threshold = float(self.cfg["preprocessing"]["pca"]["explained_variance"])
            self.pca = PCA(n_components=threshold, svd_solver="full", random_state=self.cfg["project"]["seed"])
            self.pca.fit(matrix)
        else:
            self.pca = None
        return self

    def _smooth_indicators(self, numeric_scaled: np.ndarray) -> np.ndarray:
        if not (self.use_sg and self.cfg["preprocessing"]["savgol"]["enabled"]):
            return numeric_scaled
        out = np.asarray(numeric_scaled, dtype=np.float64).copy()
        window = int(self.cfg["preprocessing"]["savgol"]["window_length"])
        poly = int(self.cfg["preprocessing"]["savgol"]["polyorder"])
        if len(out) < window:
            return out
        idx = {name: i for i, name in enumerate(NUMERIC_FEATURES)}
        for name in CLASSROOM_INDICATORS:
            j = idx[name]
            out[:, j] = savgol_filter(out[:, j], window_length=window, polyorder=poly, mode="interp")
        return np.clip(out, 0.0, 1.0)

    def _compose(self, df: pd.DataFrame, fit_stage: bool = False) -> tuple[np.ndarray, list[str]]:
        if self.scaler is None or self.encoder is None:
            raise RuntimeError("Preprocessor must be fitted before transform.")
        numeric = self.scaler.transform(df[NUMERIC_FEATURES])
        numeric = self._smooth_indicators(numeric)
        categorical = self.encoder.transform(df[CATEGORICAL_FEATURES].astype(str))
        names = list(NUMERIC_FEATURES) + list(self.encoder.get_feature_names_out(CATEGORICAL_FEATURES))
        matrix = np.hstack([numeric, categorical]).astype(np.float32)
        return matrix, names

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        matrix, _ = self._compose(df)
        if self.pca is not None:
            matrix = self.pca.transform(matrix)
        return np.asarray(matrix, dtype=np.float32)

    def fit_transform(self, train_df: pd.DataFrame) -> np.ndarray:
        self.fit(train_df)
        return self.transform(train_df)

    @property
    def retained_components(self) -> int:
        if self.pca is None:
            return len(self.feature_names_before_pca)
        return int(self.pca.n_components_)

    @property
    def explained_variance(self) -> float:
        if self.pca is None:
            return 1.0
        return float(self.pca.explained_variance_ratio_.sum())

    def scaled_indicator_values(self, df: pd.DataFrame) -> pd.DataFrame:
        if self.scaler is None:
            raise RuntimeError("Preprocessor is not fitted.")
        arr = self.scaler.transform(df[NUMERIC_FEATURES])
        idx = {name: i for i, name in enumerate(NUMERIC_FEATURES)}
        return pd.DataFrame({name: arr[:, idx[name]] for name in CLASSROOM_INDICATORS}, index=df.index)

    def transform_single_with_history(
        self,
        record: pd.DataFrame,
        indicator_history: dict[str, list[float]] | None = None,
    ) -> tuple[np.ndarray, dict[str, list[float]]]:
        """Edge-style transform using a one-sided polynomial window for indicators.

        `indicator_history` stores already-scaled indicator values. The newest record is appended,
        a degree-2 polynomial is fitted over at most the latest five points, and the polynomial is
        evaluated at the newest point. No future observation is used.
        """
        if len(record) != 1:
            raise ValueError("record must contain exactly one row")
        if self.scaler is None or self.encoder is None:
            raise RuntimeError("Preprocessor must be fitted before transform.")
        history = indicator_history or {name: [] for name in CLASSROOM_INDICATORS}
        numeric = self.scaler.transform(record[NUMERIC_FEATURES]).astype(float)
        idx = {name: i for i, name in enumerate(NUMERIC_FEATURES)}
        window = int(self.cfg["preprocessing"]["savgol"]["window_length"])
        poly = int(self.cfg["preprocessing"]["savgol"]["polyorder"])
        if self.use_sg and self.cfg["preprocessing"]["savgol"]["enabled"]:
            for name in CLASSROOM_INDICATORS:
                raw_value = float(numeric[0, idx[name]])
                seq = list(history.get(name, [])) + [raw_value]
                seq = seq[-window:]
                history[name] = seq.copy()
                if len(seq) >= poly + 1:
                    x = np.arange(len(seq), dtype=float)
                    coeff = np.polyfit(x, np.asarray(seq), deg=min(poly, len(seq) - 1))
                    numeric[0, idx[name]] = np.polyval(coeff, x[-1])
                else:
                    numeric[0, idx[name]] = raw_value
        categorical = self.encoder.transform(record[CATEGORICAL_FEATURES].astype(str))
        matrix = np.hstack([numeric, categorical]).astype(np.float32)
        if self.pca is not None:
            matrix = self.pca.transform(matrix).astype(np.float32)
        return matrix, history
