from __future__ import annotations

import math
from typing import Any


def _tf():
    import tensorflow as tf
    return tf


def selected_filters(cfg: dict[str, Any], multiplier: float) -> list[int]:
    return [max(1, int(round(int(f) * float(multiplier)))) for f in cfg["model"]["base_filters"]]


def residual_unit(x, filters: int, kernel_size: int, padding: str, activation: str, name: str):
    tf = _tf()
    shortcut = x
    if int(x.shape[-1]) != filters:
        shortcut = tf.keras.layers.Conv1D(filters, 1, padding="same", name=f"{name}_proj")(shortcut)
    y = tf.keras.layers.Conv1D(filters, kernel_size, padding=padding, activation=activation,
                               name=f"{name}_conv1")(x)
    y = tf.keras.layers.Conv1D(filters, kernel_size, padding=padding, activation=None,
                               name=f"{name}_conv2")(y)
    y = tf.keras.layers.Add(name=f"{name}_add")([shortcut, y])
    return tf.keras.layers.Activation(activation, name=f"{name}_relu")(y)


def dense_unit(x, layers: int, growth_rate: int, out_filters: int, kernel_size: int,
               padding: str, activation: str, name: str):
    tf = _tf()
    features = [x]
    current = x
    for i in range(layers):
        merged = current if i == 0 else tf.keras.layers.Concatenate(name=f"{name}_cat{i}")(features)
        bottleneck = tf.keras.layers.Conv1D(4 * growth_rate, 1, padding="same", activation=activation,
                                            name=f"{name}_bneck{i+1}")(merged)
        new = tf.keras.layers.Conv1D(growth_rate, kernel_size, padding=padding, activation=activation,
                                     name=f"{name}_conv{i+1}")(bottleneck)
        features.append(new)
        current = new
    merged = tf.keras.layers.Concatenate(name=f"{name}_out_cat")(features)
    return tf.keras.layers.Conv1D(out_filters, 1, padding="same", activation=activation,
                                  name=f"{name}_transition")(merged)


def conv_extractor(inp, cfg: dict[str, Any], filters: list[int]):
    tf = _tf()
    x = inp
    kernel = int(cfg["model"]["kernel_size"])
    padding = cfg["model"]["conv_padding"]
    activation = cfg["model"]["activation"]
    for b, f in enumerate(filters, start=1):
        x = tf.keras.layers.Conv1D(f, kernel, padding=padding, activation=activation,
                                   name=f"block{b}_entry")(x)
        for r in range(int(cfg["model"]["residual_units_per_block"])):
            x = residual_unit(x, f, kernel, padding, activation, name=f"block{b}_res{r+1}")
        x = dense_unit(
            x,
            layers=int(cfg["model"]["dense_layers"]),
            growth_rate=int(cfg["model"]["dense_growth_rate"]),
            out_filters=f,
            kernel_size=kernel,
            padding=padding,
            activation=activation,
            name=f"block{b}_dense",
        )
        x = tf.keras.layers.MaxPooling1D(
            pool_size=int(cfg["model"]["pool_size"]),
            padding=cfg["model"].get("pool_padding", "same"),
            name=f"block{b}_pool",
        )(x)
    return x


def build_model(
    input_length: int,
    cfg: dict[str, Any],
    hyperparams: dict[str, Any],
    variant: str = "full",
):
    """Build full or ablation model.

    Variants: full, cnn_only, lstm_only, mlp.
    `no_sg` and `no_pca` are preprocessing variants and therefore use `full` here.
    """
    tf = _tf()
    tf.keras.backend.clear_session()
    inp = tf.keras.Input(shape=(int(input_length), 1), name="pca_sequence")
    dropout = float(hyperparams["dropout"])
    lstm_units = int(hyperparams["lstm_units"])
    filters = selected_filters(cfg, float(hyperparams["filter_multiplier"]))

    if variant == "mlp":
        x = tf.keras.layers.Flatten()(inp)
        x = tf.keras.layers.Dense(128, activation="relu")(x)
        x = tf.keras.layers.Dropout(dropout)(x)
        x = tf.keras.layers.Dense(64, activation="relu")(x)
        x = tf.keras.layers.Dropout(dropout)(x)
    elif variant == "lstm_only":
        x = inp
        x = tf.keras.layers.LSTM(lstm_units, return_sequences=True, name="lstm1")(x)
        x = tf.keras.layers.LSTM(lstm_units, return_sequences=False, name="lstm2")(x)
        x = tf.keras.layers.Dropout(dropout, name="dropout")(x)
    elif variant == "cnn_only":
        x = conv_extractor(inp, cfg, filters)
        x = tf.keras.layers.GlobalAveragePooling1D()(x)
        x = tf.keras.layers.Dropout(dropout, name="dropout")(x)
    elif variant == "full":
        x = conv_extractor(inp, cfg, filters)
        x = tf.keras.layers.LSTM(lstm_units, return_sequences=True, name="lstm1")(x)
        x = tf.keras.layers.LSTM(lstm_units, return_sequences=False, name="lstm2")(x)
        x = tf.keras.layers.Dropout(dropout, name="dropout")(x)
    else:
        raise ValueError(f"Unknown model variant: {variant}")

    out = tf.keras.layers.Dense(int(cfg["model"]["output_classes"]), activation="softmax", name="class_probs")(x)
    model = tf.keras.Model(inp, out, name=f"TeachEdgeECL_{variant}")
    optimizer = tf.keras.optimizers.Adam(learning_rate=float(hyperparams["learning_rate"]))
    model.compile(optimizer=optimizer, loss="categorical_crossentropy", metrics=["accuracy"])
    return model


def as_sequence(X):
    import numpy as np
    X = np.asarray(X, dtype=np.float32)
    if X.ndim != 2:
        raise ValueError(f"Expected 2D feature matrix, got shape {X.shape}")
    return X[..., None]
