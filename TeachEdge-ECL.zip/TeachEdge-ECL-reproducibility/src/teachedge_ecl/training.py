from __future__ import annotations

from dataclasses import dataclass
import gc
from typing import Any
import numpy as np
import pandas as pd

from .models import build_model, as_sequence
from .seed import set_global_seed


@dataclass
class TrainResult:
    model: Any
    history: pd.DataFrame
    stopped_epoch: int
    best_epoch: int
    best_val_loss: float


def one_hot(y: np.ndarray, n_classes: int = 3) -> np.ndarray:
    y = np.asarray(y, dtype=int)
    out = np.zeros((len(y), n_classes), dtype=np.float32)
    out[np.arange(len(y)), y] = 1.0
    return out


def train_model(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_val: np.ndarray | None,
    y_val: np.ndarray | None,
    cfg: dict,
    hyperparams: dict,
    variant: str = "full",
    seed: int = 42,
    fixed_epochs: int | None = None,
    verbose: int | None = None,
) -> TrainResult:
    import tensorflow as tf

    set_global_seed(seed, cfg["training"].get("deterministic_ops", True))
    model = build_model(X_train.shape[1], cfg, hyperparams, variant=variant)
    n_classes = int(cfg["model"]["output_classes"])
    Xtr = as_sequence(X_train)
    ytr = one_hot(y_train, n_classes)
    callbacks = []
    validation_data = None

    if X_val is not None and y_val is not None:
        validation_data = (as_sequence(X_val), one_hot(y_val, n_classes))

    if fixed_epochs is None:
        epochs = int(cfg["training"]["max_epochs"])
        if validation_data is None:
            raise ValueError("Early-stopped training requires a validation set.")
        callbacks.append(
            tf.keras.callbacks.EarlyStopping(
                monitor="val_loss",
                patience=int(cfg["training"]["early_stopping_patience"]),
                restore_best_weights=bool(cfg["training"]["restore_best_weights"]),
                mode="min",
                verbose=0,
            )
        )
    else:
        epochs = int(fixed_epochs)

    h = model.fit(
        Xtr,
        ytr,
        validation_data=validation_data,
        epochs=epochs,
        batch_size=int(hyperparams["batch_size"]),
        shuffle=True,
        verbose=cfg["training"].get("verbose", 0) if verbose is None else verbose,
        callbacks=callbacks,
    )

    history = pd.DataFrame(h.history)
    history.insert(0, "epoch", np.arange(1, len(history) + 1))
    stopped_epoch = int(len(history))
    if "val_loss" in history:
        best_idx = int(history["val_loss"].to_numpy().argmin())
        best_epoch = best_idx + 1
        best_val_loss = float(history.loc[best_idx, "val_loss"])
    else:
        best_epoch = stopped_epoch
        best_val_loss = float("nan")
    return TrainResult(model, history, stopped_epoch, best_epoch, best_val_loss)


def predict_probabilities(model, X: np.ndarray, batch_size: int = 256) -> np.ndarray:
    return np.asarray(model.predict(as_sequence(X), batch_size=batch_size, verbose=0), dtype=float)


def cleanup_model(model=None) -> None:
    try:
        import tensorflow as tf
        if model is not None:
            del model
        tf.keras.backend.clear_session()
    except Exception:
        pass
    gc.collect()
