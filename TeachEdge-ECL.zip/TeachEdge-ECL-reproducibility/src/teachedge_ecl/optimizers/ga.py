from __future__ import annotations

import numpy as np
import pandas as pd
from .common import SearchSpace, SearchResult, evaluate_and_log


class GeneticAlgorithmOptimizer:
    """Budget-exact steady-state GA using the manuscript's selection/crossover/mutation rates."""

    def __init__(self, cfg: dict, seed: int = 42, budget: int = 610):
        self.cfg = cfg
        self.seed = int(seed)
        self.space = SearchSpace(cfg)
        g = cfg["ga"]
        self.pop = int(g["population"])
        self.tournament = int(g["tournament_size"])
        self.crossover_rate = float(g["crossover_rate"])
        self.mutation_rate = float(g["mutation_rate"])
        self.mutation_scale = float(g.get("mutation_scale", 0.1))
        self.budget = int(budget)

    def run(self, objective) -> SearchResult:
        rng = np.random.default_rng(self.seed)
        x = self.space.sample(rng, self.pop)
        f = np.full(self.pop, np.inf)
        rows = []
        eval_no = 0
        best_f = np.inf
        best_x = None
        for i in range(self.pop):
            eval_no += 1
            f[i], _ = evaluate_and_log(objective, self.space, x[i], eval_no, "GA", 0, "initial",
                                       self.seed, best_f, rows)
            if f[i] < best_f:
                best_f, best_x = float(f[i]), x[i].copy()

        def select():
            ids = rng.choice(self.pop, size=self.tournament, replace=False)
            return x[ids[np.argmin(f[ids])]].copy()

        generation = 0
        while eval_no < self.budget:
            generation += 1
            p1, p2 = select(), select()
            if rng.random() < self.crossover_rate:
                alpha = rng.random(self.space.dim)
                child = alpha * p1 + (1 - alpha) * p2
            else:
                child = p1.copy()
            mask = rng.random(self.space.dim) < self.mutation_rate
            if np.any(mask):
                child[mask] += rng.normal(0.0, self.mutation_scale, size=mask.sum()) * self.space.hop[mask]
            child = self.space.clip(child)
            eval_no += 1
            child_f, _ = evaluate_and_log(objective, self.space, child, eval_no, "GA", generation,
                                          "offspring", self.seed, best_f, rows)
            worst = int(np.argmax(f))
            if child_f < f[worst]:
                x[worst], f[worst] = child, child_f
            if child_f < best_f:
                best_f, best_x = float(child_f), child.copy()
        return SearchResult(best_x, self.space.decode(best_x), best_f, eval_no, pd.DataFrame(rows))
