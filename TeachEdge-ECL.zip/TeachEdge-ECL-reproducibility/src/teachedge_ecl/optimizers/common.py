from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Any
import json
import numpy as np
import pandas as pd


@dataclass
class SearchResult:
    best_x: np.ndarray
    best_params: dict[str, Any]
    best_fitness: float
    evaluations: int
    log: pd.DataFrame


class SearchSpace:
    """Five-dimensional paper search space.

    Vector order:
      0 learning rate
      1 filter multiplier
      2 LSTM units
      3 dropout
      4 batch-size index (0,1,2 -> 16,32,64)
    """

    names = ["learning_rate", "filter_multiplier", "lstm_units", "dropout", "batch_index"]

    def __init__(self, cfg: dict):
        s = cfg["search_space"]
        self.batch_values = np.asarray(s["batch_size"], dtype=int)
        self.lb = np.array([
            float(s["learning_rate"][0]),
            float(s["filter_multiplier"][0]),
            float(s["lstm_units"][0]),
            float(s["dropout"][0]),
            0.0,
        ], dtype=float)
        self.ub = np.array([
            float(s["learning_rate"][1]),
            float(s["filter_multiplier"][1]),
            float(s["lstm_units"][1]),
            float(s["dropout"][1]),
            float(len(self.batch_values) - 1),
        ], dtype=float)

    @property
    def dim(self) -> int:
        return len(self.lb)

    @property
    def hop(self) -> np.ndarray:
        return self.ub - self.lb

    def sample(self, rng: np.random.Generator, n: int = 1) -> np.ndarray:
        return rng.uniform(self.lb, self.ub, size=(n, self.dim))

    def clip(self, x: np.ndarray) -> np.ndarray:
        return np.clip(np.asarray(x, dtype=float), self.lb, self.ub)

    def decode(self, x: np.ndarray) -> dict[str, Any]:
        x = self.clip(x)
        batch_idx = int(np.clip(np.rint(x[4]), 0, len(self.batch_values) - 1))
        return {
            "learning_rate": float(x[0]),
            "filter_multiplier": float(x[1]),
            "lstm_units": int(np.clip(np.rint(x[2]), self.lb[2], self.ub[2])),
            "dropout": float(x[3]),
            "batch_size": int(self.batch_values[batch_idx]),
        }

    def encode(self, params: dict[str, Any]) -> np.ndarray:
        batch = int(params["batch_size"])
        batch_idx = int(np.argmin(np.abs(self.batch_values - batch)))
        return np.array([
            float(params["learning_rate"]),
            float(params["filter_multiplier"]),
            float(params["lstm_units"]),
            float(params["dropout"]),
            float(batch_idx),
        ])


def evaluate_and_log(
    objective: Callable[[dict[str, Any], int], float],
    space: SearchSpace,
    x: np.ndarray,
    eval_no: int,
    optimizer: str,
    iteration: int,
    proposal: str,
    seed: int,
    best_so_far: float,
    rows: list[dict],
) -> tuple[float, float]:
    params = space.decode(x)
    fitness = float(objective(params, eval_no))
    best = min(best_so_far, fitness)
    row = {
        "optimizer": optimizer,
        "evaluation": int(eval_no),
        "iteration": int(iteration),
        "proposal": proposal,
        "fitness": fitness,
        "best_fitness": best,
        "learning_rate": params["learning_rate"],
        "filter_multiplier": params["filter_multiplier"],
        "lstm_units": params["lstm_units"],
        "dropout": params["dropout"],
        "batch_size": params["batch_size"],
        "candidate_json": json.dumps(params, sort_keys=True),
    }
    rows.append(row)
    return fitness, best
