from __future__ import annotations

import numpy as np
import pandas as pd
from .common import SearchSpace, SearchResult, evaluate_and_log


class RandomSearchOptimizer:
    def __init__(self, cfg: dict, seed: int = 42, budget: int = 610):
        self.cfg = cfg
        self.seed = int(seed)
        self.space = SearchSpace(cfg)
        self.budget = int(budget)

    def run(self, objective) -> SearchResult:
        rng = np.random.default_rng(self.seed)
        rows = []
        best_f = np.inf
        best_x = None
        for eval_no in range(1, self.budget + 1):
            x = self.space.sample(rng, 1)[0]
            f, _ = evaluate_and_log(objective, self.space, x, eval_no, "Random", eval_no,
                                    "uniform", self.seed, best_f, rows)
            if f < best_f:
                best_f, best_x = float(f), x.copy()
        return SearchResult(best_x, self.space.decode(best_x), best_f, self.budget, pd.DataFrame(rows))
