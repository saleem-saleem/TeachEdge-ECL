from __future__ import annotations

import numpy as np

from .common import SearchSpace, SearchResult, evaluate_and_log


class EgretSwarmOptimizer:
    """ESO implementation following manuscript Equations (24)-(38).

    Numerical safeguards (epsilon in norms and Adam denominator) are implementation details
    needed to avoid division by zero. Search-space clipping is applied after each move.
    """

    def __init__(self, cfg: dict, seed: int = 42):
        self.cfg = cfg
        self.seed = int(seed)
        self.space = SearchSpace(cfg)
        e = cfg["eso"]
        self.P = int(e["squads"])
        self.tmax = int(e["iterations"])
        self.beta1 = float(e["beta1"])
        self.beta2 = float(e["beta2"])
        self.accept_worse = float(e["worse_acceptance_probability"])
        self.rh_rg_upper = float(e["rh_rg_upper"])
        self.eps = float(e.get("epsilon", 1e-8))

    def run(self, objective) -> SearchResult:
        rng = np.random.default_rng(self.seed)
        x = self.space.sample(rng, self.P)
        f = np.empty(self.P)
        rows = []
        eval_no = 0
        best_f = np.inf
        best_x = None

        # Observation-model state for each squad.
        w = np.zeros_like(x)
        m = np.zeros_like(x)
        n = np.zeros_like(x)
        direction = np.zeros_like(x)

        # Personal best state.
        pbest_x = x.copy()
        pbest_f = np.full(self.P, np.inf)
        pbest_d = np.zeros_like(x)

        # Initial P evaluations: this is why the total is P + 3*P*tmax = 610.
        for i in range(self.P):
            eval_no += 1
            f[i], best_f = evaluate_and_log(
                objective, self.space, x[i], eval_no, "ESO", 0, "initial", self.seed,
                best_f, rows,
            )
            pbest_f[i] = f[i]
            if best_x is None or f[i] < best_f + 1e-15:
                # Retrieve actual global best explicitly to avoid tie ambiguity.
                j = int(np.argmin(f[: i + 1]))
                best_x = x[j].copy()
                best_f = float(f[j])

        gbest_x = best_x.copy()
        gbest_f = float(best_f)
        gbest_d = np.zeros(self.space.dim)

        for t in range(1, self.tmax + 1):
            for i in range(self.P):
                # Eq. 24-27: linear observation model, error gradient, unit direction.
                y_hat = float(np.dot(w[i], x[i]))
                grad = (y_hat - f[i]) * x[i]
                grad_norm = np.linalg.norm(grad)
                d_i = grad / (grad_norm + self.eps)

                # Eq. 28-29: correction directions toward squad/personal and global best.
                def correction(best_pos, best_fit, stored_d):
                    delta = best_pos - x[i]
                    dist = np.linalg.norm(delta)
                    if dist < self.eps:
                        return stored_d.copy()
                    slope = (best_fit - f[i]) / (dist + self.eps)
                    return (delta / (dist + self.eps)) * slope + stored_d

                d_h = correction(pbest_x[i], pbest_f[i], pbest_d[i])
                d_g = correction(gbest_x, gbest_f, gbest_d)
                rh = rng.uniform(0.0, self.rh_rg_upper)
                rg = rng.uniform(0.0, self.rh_rg_upper)
                g_int = (1.0 - rh - rg) * d_i + rh * d_h + rg * d_g

                # Eq. 31-33: adaptive moment update of observation weights.
                m[i] = self.beta1 * m[i] + (1.0 - self.beta1) * g_int
                n[i] = self.beta2 * n[i] + (1.0 - self.beta2) * (g_int * g_int)
                w[i] = w[i] - m[i] / (np.sqrt(n[i]) + self.eps)

                # Eq. 34: sit-and-wait candidate A.
                decay = np.exp(-t / (0.1 * self.tmax))
                x_a = x[i] + decay * 0.1 * self.space.hop * g_int

                # Eq. 35: random-walk candidate B.
                rb = rng.uniform(-np.pi / 2 + 1e-6, np.pi / 2 - 1e-6, size=self.space.dim)
                x_b = x[i] + np.tan(rb) * self.space.hop / (1.0 + t)

                # Eq. 36: encircling candidate C as written in the manuscript.
                rh2 = rng.uniform(0.0, self.rh_rg_upper)
                rg2 = rng.uniform(0.0, self.rh_rg_upper)
                x_c = (1.0 - rh2 - rg2) * x[i] + rh2 * (pbest_x[i] - x[i]) + rg2 * (gbest_x - x[i])

                candidates = [self.space.clip(z) for z in (x_a, x_b, x_c)]
                fits = []
                for label, cand in zip(("egret_A", "egret_B", "egret_C"), candidates):
                    eval_no += 1
                    fit, best_logged = evaluate_and_log(
                        objective, self.space, cand, eval_no, "ESO", t, label, self.seed,
                        gbest_f, rows,
                    )
                    fits.append(fit)
                    if fit < gbest_f:
                        gbest_f = float(fit)
                        gbest_x = cand.copy()
                        gbest_d = g_int.copy()

                # Eq. 37-38: best of the three; accept if better, or with probability 0.3.
                j = int(np.argmin(fits))
                selected_x = candidates[j]
                selected_f = float(fits[j])
                if selected_f < f[i] or rng.random() < self.accept_worse:
                    x[i] = selected_x
                    f[i] = selected_f
                    direction[i] = g_int

                if f[i] < pbest_f[i]:
                    pbest_f[i] = f[i]
                    pbest_x[i] = x[i].copy()
                    pbest_d[i] = direction[i].copy()
                if pbest_f[i] < gbest_f:
                    gbest_f = float(pbest_f[i])
                    gbest_x = pbest_x[i].copy()
                    gbest_d = pbest_d[i].copy()

        expected = self.P + 3 * self.P * self.tmax
        if eval_no != expected:
            raise AssertionError(f"ESO budget error: got {eval_no}, expected {expected}")
        import pandas as pd
        return SearchResult(
            best_x=gbest_x,
            best_params=self.space.decode(gbest_x),
            best_fitness=float(gbest_f),
            evaluations=eval_no,
            log=pd.DataFrame(rows),
        )
