from __future__ import annotations

import numpy as np
import pandas as pd
from .common import SearchSpace, SearchResult, evaluate_and_log


class ParticleSwarmOptimizer:
    def __init__(self, cfg: dict, seed: int = 42, budget: int = 610):
        self.cfg = cfg
        self.seed = int(seed)
        self.space = SearchSpace(cfg)
        self.pop = int(cfg["pso"]["population"])
        self.w = float(cfg["pso"]["inertia"])
        self.c1 = float(cfg["pso"]["c1"])
        self.c2 = float(cfg["pso"]["c2"])
        self.budget = int(budget)

    def run(self, objective) -> SearchResult:
        rng = np.random.default_rng(self.seed)
        x = self.space.sample(rng, self.pop)
        v = rng.uniform(-0.1, 0.1, size=x.shape) * self.space.hop
        f = np.full(self.pop, np.inf)
        pbest_x = x.copy()
        pbest_f = np.full(self.pop, np.inf)
        gbest_x = None
        gbest_f = np.inf
        rows = []
        eval_no = 0
        for i in range(self.pop):
            eval_no += 1
            f[i], _ = evaluate_and_log(objective, self.space, x[i], eval_no, "PSO", 0, "initial",
                                       self.seed, gbest_f, rows)
            pbest_f[i] = f[i]
            if f[i] < gbest_f:
                gbest_f, gbest_x = float(f[i]), x[i].copy()
        generation = 0
        while eval_no < self.budget:
            generation += 1
            for i in range(self.pop):
                if eval_no >= self.budget:
                    break
                r1 = rng.random(self.space.dim)
                r2 = rng.random(self.space.dim)
                v[i] = self.w * v[i] + self.c1 * r1 * (pbest_x[i] - x[i]) + self.c2 * r2 * (gbest_x - x[i])
                x[i] = self.space.clip(x[i] + v[i])
                eval_no += 1
                f[i], _ = evaluate_and_log(objective, self.space, x[i], eval_no, "PSO", generation,
                                           "particle", self.seed, gbest_f, rows)
                if f[i] < pbest_f[i]:
                    pbest_f[i], pbest_x[i] = float(f[i]), x[i].copy()
                if f[i] < gbest_f:
                    gbest_f, gbest_x = float(f[i]), x[i].copy()
        return SearchResult(gbest_x, self.space.decode(gbest_x), gbest_f, eval_no, pd.DataFrame(rows))
