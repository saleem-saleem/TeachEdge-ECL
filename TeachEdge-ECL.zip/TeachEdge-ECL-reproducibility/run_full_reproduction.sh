#!/usr/bin/env bash
set -euo pipefail
python scripts/01_validate_dataset.py
python scripts/02_run_optimizer.py --optimizer eso
python scripts/03_train_final.py
python scripts/04_evaluate_holdout.py
python scripts/05_cross_validate.py
python scripts/06_ablation.py
python scripts/07_optimizer_benchmark.py
python scripts/08_baselines.py
python scripts/09_permutation_importance.py
python scripts/10_decision_support.py
python scripts/11_export_tflite.py
python scripts/13_make_figures_tables.py
python scripts/14_verify_reproducibility.py
